# OrderPal 📦

A mobile-first web app (installable as a PWA on Android) for small home-based
sellers who take orders through WhatsApp. Paste a customer's message, let AI
extract the order details, track who has paid, and get reminded about unpaid
orders.

**What's working in v0.1:** sign up / login (email + Google), paste-a-WhatsApp-message
→ AI order extraction (Claude Haiku), editable order form, manual order entry,
orders list with Pending / Paid / Delivered statuses and filters, total-owed
header, 20-free-orders paywall, 50-orders-per-day limit (both enforced on the
server), default currency setting, light/dark mode, installable PWA.

**Phase 2 (built, Oct 2026):** real Customers tab (derived from your orders —
order history, total owed/paid, unpaid totals by currency), AI payment
reminders with an editable draft + wa.me link (OrderPal never auto-sends
WhatsApp messages) and an overdue list with a server-side 50/day draft limit,
a real weekly summary (last 7 days: orders, paid, unpaid, new customers, top
customers), and subscription management — Subscribe monthly/yearly,
Settings → Manage subscription (cancel, switch plan, update card via the
gateway's hosted flow), webhook-verified plan updates, and the 3-attempt /
5-day failed-renewal rule. **The payment gateway itself is still
sandbox/stub-only** (see §11): the app code, limits, and webhook handling
are real, but no live Safepay/PayPro checkout has been tested yet, because
that needs a merchant account. Prices unchanged: $15/mo, $150/yr.

---

## 1. What you need (all free to start)

| Thing | Where to get it | Cost |
|---|---|---|
| Supabase project | https://supabase.com → New project | Free tier |
| Anthropic API key | https://console.anthropic.com → API keys | Pay-as-you-go, Haiku is the cheapest model |
| Vercel account (for hosting) | https://vercel.com | Free tier |

## 2. Set up the database (5 minutes)

1. In Supabase, open your project → **SQL Editor** → **New query**.
2. Open `supabase/schema.sql` from this repo, paste it in, and press **Run**.
   This creates the `profiles` and `orders` tables, turns on row-level security
   (so each user only ever sees their own data), and adds a trigger that creates
   a profile automatically when someone signs up.

## 3. Set up login (5 minutes)

1. Supabase → **Authentication** → **Providers** → **Email**: enabled by default.
   For the quickest testing, turn **"Confirm email" OFF**
   (Authentication → Providers → Email → Confirm email). You can turn it back on later.
2. For Google login: **Authentication** → **Providers** → **Google** → enable it.
   - Create OAuth credentials at https://console.cloud.google.com/apis/credentials
     (OAuth client ID, type "Web application").
   - Authorized redirect URI: `https://<your-supabase-ref>.supabase.co/auth/v1/callback`
     (Supabase shows you the exact callback URL on the Google provider page — copy it).
   - Paste the Client ID and Client Secret into Supabase and save.

## 4. Get your keys

1. Supabase → **Project Settings** → **API**: copy the **Project URL** and the
   **anon public** key.
2. Anthropic → https://console.anthropic.com → **API keys** → create one
   (starts with `sk-ant-`). Add a small spending limit in Billing for safety.

## 5. Run it on your computer

```bash
cd orderpal
cp .env.example .env        # then fill in your three keys
npm install
npm run dev                 # open http://localhost:3000 on your phone's browser
```

> On your phone, use your computer's local address (e.g. `http://192.168.1.5:3000`)
> while on the same Wi-Fi to test the mobile layout.

## 6. Put it on the internet (free)

1. Push this folder to a GitHub repo.
2. Vercel → **Add New Project** → import the repo.
3. Add the same three environment variables
   (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `ANTHROPIC_API_KEY`)
   in Vercel → Project → Settings → Environment Variables.
4. Deploy. You'll get an `https://orderpal-....vercel.app` link.

## 7. Install it on Android like a real app

1. Open your Vercel link in **Chrome** on your Android phone.
2. Tap the ⋮ menu → **"Add to Home screen"** → **Install**.
3. OrderPal now opens full-screen from your home screen, like a native app.

## 8. Payments (phase 2 — read before you need it)

OrderPal is built for a Pakistani merchant who charges international customers in
USD by card. The plan:

- **Gateway:** Safepay first (https://getsafepay.com). Create a merchant account,
  complete verification, and get your **API keys** (sandbox keys first).
- If Safepay can't do international USD cards with recurring billing, the fallback
  is **PayPro** — all gateway code will live in one module (`lib/payments/`) so it
  can be swapped without rewriting the app.
- **Sandbox first:** Safepay gives you test cards — run a full monthly and yearly
  signup in sandbox, check the webhook hits your `/api/webhooks/safepay` endpoint,
  then switch the keys to live.
- **Webhooks:** in the Safepay dashboard, point subscription events
  (created / renewed / failed / canceled) at
  `https://your-app.vercel.app/api/webhooks/safepay`. The app verifies the webhook
  signature, updates the user's plan (`active`, `past_due`, `canceled`), retries
  failed renewals 3 times over 5 days, then drops the account back to free-plan rules.
- **Never store card numbers** — use Safepay's hosted checkout / secure fields and
  keep only the token they return.

## 11. Phase 2 — merchant / sandbox walkthrough (do this before going live)

Phase 2's non-payment features work as soon as the database migration below
is run. Payments need a merchant account — nothing here fakes one.

### Step 1 — Run the Phase 2 database migration
1. Supabase → **SQL Editor** → **New query**.
2. Open `supabase/phase2-schema.sql`, paste it in, press **Run**.
   This adds `subscriptions`, `reminder_logs`, and `subscription_events`
   (webhook dedupe), all with row-level security so each user only sees
   their own rows. Do not re-run `schema.sql` — it is the v0.1 baseline.
3. Until this migration is run, Customers / Summary / Reminders still work
   (they read the existing `orders` table), but reminder-draft counting and
   subscription rows will not persist.

### Step 2 — Create a Safepay merchant account (sandbox first)
1. Go to Safepay (https://getsafepay.com) and create a merchant account.
2. Complete whatever verification Safepay asks for, then get your
   **sandbox API keys** — never start with live keys.
3. In the Safepay dashboard, confirm two things in writing before wiring
   anything up, and keep the answers in the repo notes:
   - Does your Safepay account support **international USD cards with
     recurring billing** (subscriptions)? If not, switch to the PayPro
     fallback (set `PAYMENT_GATEWAY=paypro` and repeat this walkthrough
     with PayPro) — do not force a one-off-payments account to act like
     subscriptions.
   - What are the exact **subscription / recurring-billing API fields**,
     the **hosted-checkout creation call**, and the **webhook event names
     and signature format**? The current adapters in `lib/payments/` are
     deliberately stubs: they refuse to guess these, because the exact
     fields were not verified against a live merchant dashboard. Fill
     them into `lib/payments/safepay.ts` (or `paypro.ts`) and only then
     will Subscribe actually open a checkout.

### Step 3 — Set the env vars (Vercel, not just your laptop)
Add these in Vercel → Project → Settings → Environment Variables:
- `PAYMENT_GATEWAY=safepay`, `PAYMENT_MODE=sandbox`
- `SAFEPAY_API_KEY`, `SAFEPAY_SECRET` (sandbox keys)
- `SAFEPAY_WEBHOOK_SECRET` (or `PAYMENT_WEBHOOK_SECRET` if your gateway
  uses one shared secret)
- `SUPABASE_SERVICE_ROLE_KEY` — server-only, for webhook handlers. Never
  put it in client code, never commit it, never share it in chat.

### Step 4 — Point webhooks at the app
In the Safepay dashboard, point subscription events (created / renewed /
failed / canceled) at:
- `https://your-app.vercel.app/api/webhooks/safepay`
  (or `/api/webhooks/paypro` for the fallback gateway).
The app verifies the HMAC-SHA256 signature before trusting any event, and
dedupes redeliveries by event id. A request with a bad or missing signature
is rejected (401) and nothing is changed.

### Step 5 — Test in sandbox, in this order
1. Subscribe monthly in sandbox → webhook should set the account to
   `active` (check Settings → Plan).
2. Subscribe yearly in sandbox → same, with `yearly` interval.
3. Trigger a failed renewal in sandbox → account becomes `past_due`;
   after 3 failures and 5 days from the first failure, new orders follow
   free-plan rules (existing orders stay viewable/editable).
4. Cancel in sandbox → account becomes `canceled`.
5. Update card in sandbox → it must happen on the gateway's hosted page,
   never inside OrderPal.
6. Only when all five pass, switch the keys to live and set
   `PAYMENT_MODE=live` — and re-run the same five tests with a real
   (small) payment before announcing the paid plan.

### What still needs the user's merchant account and keys
- Safepay (or PayPro) merchant account + verification.
- Sandbox API keys + webhook secret + the exact subscription/checkout
  fields and webhook event names from that dashboard.
- `SUPABASE_SERVICE_ROLE_KEY` for webhook handlers.
- The Phase 2 migration run in Supabase (Step 1).
- GitHub repo + Vercel deployment (see §6) so webhooks have a public URL.

## 9. Changing prices and limits

Everything lives in **`lib/config.ts`**: `freeOrderLimit` (20), `monthlyPriceUSD`
(15), `yearlyPriceUSD` (150), `dailyOrderLimit` (50), `dailyReminderLimit` (50).
Change them there — nowhere else.

## 10. How the limits work (so you trust them)

- The **20 free orders** count every order ever created (pasted or manual). When
  the 20th is saved, creating more is blocked server-side with a paywall screen.
  Old orders stay viewable and editable forever.
- The **50/day limit** resets at midnight in the *user's* timezone (saved from
  their phone automatically). The count is done in the API route, so it can't be
  bypassed by editing the app in the browser.

## Tech notes

- Next.js 14 (App Router) + Tailwind + Supabase (auth + Postgres) + Anthropic SDK.
- The Anthropic key lives only in server environment variables — the phone app
  never sees it. Extraction runs in `app/api/extract/route.ts`.
- No internet / AI failure: the app shows a clear message and falls back to the
  manual order form. Nothing is ever lost silently.
