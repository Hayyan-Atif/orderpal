"use client";

import { useState } from "react";
import { apiJson } from "@/lib/api";
import { config } from "@/lib/config";
import { formatMoney } from "@/lib/currencies";

/** Shown when the free plan's order limit is reached. */
export default function Paywall({ onClose }: { onClose: () => void }) {
  const monthly = config.monthlyPriceUSD;
  const yearly = config.yearlyPriceUSD;
  const [interval, setInterval] = useState<"monthly" | "yearly">("yearly");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function subscribe() {
    setBusy(true);
    setError("");
    try {
      const d = await apiJson<{ checkoutUrl: string }>("/api/subscription/checkout", {
        method: "POST",
        body: JSON.stringify({ interval }),
      });
      window.location.href = d.checkoutUrl;
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Checkout is not connected yet."
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center">
      <div className="w-full max-w-md rounded-t-3xl bg-white p-6 pb-10 dark:bg-gray-900 sm:rounded-3xl">
        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-gray-200 dark:bg-gray-700" />
        <h2 className="text-xl font-bold">You&apos;ve used your {config.freeOrderLimit} free orders.</h2>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          Subscribe to keep tracking unlimited orders. Your existing orders stay
          viewable and editable either way.
        </p>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <button
            onClick={() => setInterval("monthly")}
            className={`rounded-2xl border p-4 text-left ${interval === "monthly" ? "border-2 border-brand-600" : "border-gray-200 dark:border-gray-700"}`}
          >
            <p className="text-sm font-semibold text-gray-500">Monthly</p>
            <p className="mt-1 text-2xl font-bold">${monthly}</p>
            <p className="text-xs text-gray-400">per month, cancel anytime</p>
          </button>
          <button
            onClick={() => setInterval("yearly")}
            className={`relative rounded-2xl border p-4 text-left ${interval === "yearly" ? "border-2 border-brand-600" : "border-gray-200 dark:border-gray-700"}`}
          >
            <span className="absolute -top-3 left-3 rounded-full bg-brand-600 px-2 py-0.5 text-xs font-bold text-white">
              {config.yearlyBadge}
            </span>
            <p className="text-sm font-semibold text-gray-500">Yearly</p>
            <p className="mt-1 text-2xl font-bold">${yearly}</p>
            <p className="text-xs text-gray-400">per year, cancel anytime</p>
          </button>
        </div>

        <div className="mt-4 flex items-center justify-center gap-2">
          <span className="rounded-md bg-[#1a1f71] px-2 py-1 text-xs font-bold italic text-white">VISA</span>
          <span className="flex items-center rounded-md bg-gray-100 px-2 py-1 dark:bg-gray-800">
            <span className="h-4 w-4 rounded-full bg-red-500/80" />
            <span className="-ml-2 h-4 w-4 rounded-full bg-yellow-500/80" />
            <span className="ml-1 text-xs font-bold text-gray-600 dark:text-gray-300">Mastercard</span>
          </span>
        </div>
        <p className="mt-2 text-center text-xs text-gray-400">
          Cards are handled on the payment gateway&apos;s secure checkout.
          OrderPal never stores your card number.
        </p>

        {error && (
          <p className="mt-3 rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>
        )}
        <button
          onClick={subscribe}
          disabled={busy}
          className="mt-4 w-full rounded-xl bg-brand-600 py-3.5 font-semibold text-white disabled:opacity-50"
        >
          {busy ? "Opening checkout…" : `Subscribe — $${interval === "monthly" ? monthly : yearly}${interval === "monthly" ? "/mo" : "/yr"}`}
        </button>
        <button onClick={onClose} className="mt-2 w-full py-2 text-sm text-gray-500">
          Not now
        </button>
      </div>
    </div>
  );
}

/** Friendly notice when the 50-orders-per-day limit is reached. */
export function DailyLimitNotice({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center">
      <div className="w-full max-w-md rounded-t-3xl bg-white p-6 pb-10 text-center dark:bg-gray-900 sm:rounded-3xl">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-amber-100 text-2xl dark:bg-amber-900">
          ⏳
        </div>
        <h2 className="text-lg font-bold">That&apos;s enough for today!</h2>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          You&apos;ve reached today&apos;s limit of {config.dailyOrderLimit} orders. It resets
          tomorrow at midnight. Your existing orders are still fully viewable and editable.
        </p>
        <button
          onClick={onClose}
          className="mt-5 w-full rounded-xl bg-brand-600 py-3 font-semibold text-white"
        >
          Got it
        </button>
      </div>
    </div>
  );
}

/** Total still owed, grouped by currency. */
export function OwedHeader({ totals }: { totals: Record<string, number> }) {
  const entries = Object.entries(totals).filter(([, v]) => v > 0);
  if (entries.length === 0) {
    return (
      <div className="rounded-2xl bg-brand-50 p-4 text-center dark:bg-brand-700/20">
        <p className="text-sm font-medium text-brand-700 dark:text-brand-100">
          All caught up — nothing owed right now. 🎉
        </p>
      </div>
    );
  }
  return (
    <div className="rounded-2xl bg-brand-600 p-4 text-white">
      <p className="text-xs uppercase tracking-wide opacity-80">Still owed</p>
      <p className="mt-1 text-2xl font-bold">
        {entries.map(([cur, amt]) => formatMoney(amt, cur)).join("  ·  ")}
      </p>
    </div>
  );
}
