"use client";

import { useEffect } from "react";

// Applies the saved theme (light/dark/system) before first paint to avoid flashing.
export default function ThemeScript() {
  useEffect(() => {
    const saved = localStorage.getItem("orderpal-theme") || "system";
    const dark =
      saved === "dark" ||
      (saved === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.classList.toggle("dark", dark);
  }, []);
  return null;
}

export function setThemeChoice(choice: "light" | "dark" | "system") {
  localStorage.setItem("orderpal-theme", choice);
  const dark =
    choice === "dark" ||
    (choice === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
}
