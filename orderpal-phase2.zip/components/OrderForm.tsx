"use client";

import { CURRENCIES } from "@/lib/currencies";
import type { OrderItem } from "@/lib/types";

export interface OrderFormData {
  customer_name: string;
  customer_phone: string;
  items: OrderItem[];
  total: number;
  currency: string;
  due_date: string;
  notes: string;
}

export const emptyForm = (currency: string): OrderFormData => ({
  customer_name: "",
  customer_phone: "",
  items: [{ name: "", qty: 1, price: 0 }],
  total: 0,
  currency,
  due_date: "",
  notes: "",
});

const inputCls =
  "w-full rounded-xl border border-gray-300 px-4 py-3 dark:border-gray-700 dark:bg-gray-800";

export default function OrderForm({
  form,
  setForm,
  onSave,
  saving,
  saveLabel,
}: {
  form: OrderFormData;
  setForm: (f: OrderFormData) => void;
  onSave: () => void;
  saving: boolean;
  saveLabel: string;
}) {
  function setItems(items: OrderItem[]) {
    const total = items.reduce((s, i) => s + Number(i.qty || 0) * Number(i.price || 0), 0);
    setForm({ ...form, items, total });
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="mb-1 block text-sm font-medium text-gray-500">Customer name *</label>
        <input
          className={inputCls}
          value={form.customer_name}
          onChange={(e) => setForm({ ...form, customer_name: e.target.value })}
          placeholder="e.g. Ayesha Khan"
        />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-gray-500">Phone (optional)</label>
        <input
          className={inputCls}
          value={form.customer_phone}
          onChange={(e) => setForm({ ...form, customer_phone: e.target.value })}
          placeholder="e.g. +92 300 1234567"
          inputMode="tel"
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-500">Items</label>
        <div className="space-y-2">
          {form.items.map((item, idx) => (
            <div key={idx} className="flex gap-2">
              <input
                className={`${inputCls} flex-1`}
                placeholder="Item name"
                value={item.name}
                onChange={(e) => {
                  const items = [...form.items];
                  items[idx] = { ...items[idx], name: e.target.value };
                  setItems(items);
                }}
              />
              <input
                className={`${inputCls} w-16 text-center`}
                type="number"
                min={1}
                value={item.qty}
                onChange={(e) => {
                  const items = [...form.items];
                  items[idx] = { ...items[idx], qty: Number(e.target.value) };
                  setItems(items);
                }}
              />
              <input
                className={`${inputCls} w-24`}
                type="number"
                min={0}
                step="any"
                placeholder="Price"
                value={item.price || ""}
                onChange={(e) => {
                  const items = [...form.items];
                  items[idx] = { ...items[idx], price: Number(e.target.value) };
                  setItems(items);
                }}
              />
              {form.items.length > 1 && (
                <button
                  type="button"
                  onClick={() => setItems(form.items.filter((_, i) => i !== idx))}
                  className="px-2 text-xl text-gray-400"
                  aria-label="Remove item"
                >
                  ×
                </button>
              )}
            </div>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setItems([...form.items, { name: "", qty: 1, price: 0 }])}
          className="mt-2 text-sm font-semibold text-brand-600"
        >
          ＋ Add item
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-500">Total</label>
          <input
            className={inputCls}
            type="number"
            min={0}
            step="any"
            value={form.total || ""}
            onChange={(e) => setForm({ ...form, total: Number(e.target.value) })}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-500">Currency</label>
          <select
            className={inputCls}
            value={form.currency}
            onChange={(e) => setForm({ ...form, currency: e.target.value })}
          >
            {CURRENCIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.code} ({c.symbol})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-500">Delivery / due date (optional)</label>
        <input
          type="date"
          className={inputCls}
          value={form.due_date}
          onChange={(e) => setForm({ ...form, due_date: e.target.value })}
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-500">Notes (optional)</label>
        <textarea
          className={`${inputCls} min-h-20`}
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          placeholder="Address, customization, anything else…"
        />
      </div>

      <button
        onClick={onSave}
        disabled={saving || !form.customer_name.trim()}
        className="w-full rounded-2xl bg-brand-600 py-4 text-lg font-bold text-white shadow-lg shadow-brand-600/30 disabled:opacity-50"
      >
        {saving ? "Saving…" : saveLabel}
      </button>
    </div>
  );
}
