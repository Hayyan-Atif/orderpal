"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { apiJson } from "@/lib/api";
import { formatMoney } from "@/lib/currencies";
import type { Order, OrdersResponse } from "@/lib/types";
import { useSession } from "@/lib/use-session";
import OrderForm, { type OrderFormData } from "@/components/OrderForm";

export default function OrderDetailPage() {
  const { session, loading } = useSession();
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [order, setOrder] = useState<Order | null>(null);
  const [form, setForm] = useState<OrderFormData | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (!session) return;
    apiJson<OrdersResponse>("/api/orders")
      .then((d) => {
        const o = d.orders.find((x) => x.id === params.id);
        if (!o) {
          setError("Order not found.");
          return;
        }
        setOrder(o);
        setForm({
          customer_name: o.customer_name,
          customer_phone: o.customer_phone ?? "",
          items: o.items.length > 0 ? o.items : [{ name: "", qty: 1, price: 0 }],
          total: Number(o.total),
          currency: o.currency,
          due_date: o.due_date ?? "",
          notes: o.notes ?? "",
        });
      })
      .catch((e: Error) => setError(e.message));
  }, [session, params.id]);

  async function patch(patch: Record<string, unknown>) {
    setSaving(true);
    setError("");
    try {
      const data = await apiJson<{ order: Order }>(`/api/orders/${params.id}`, {
        method: "PATCH",
        body: JSON.stringify(patch),
      });
      setOrder(data.order);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not update.");
    } finally {
      setSaving(false);
    }
  }

  async function handleSave() {
    if (!form) return;
    await patch({
      customer_name: form.customer_name,
      customer_phone: form.customer_phone || null,
      items: form.items.filter((i) => i.name.trim()),
      total: form.total,
      currency: form.currency,
      due_date: form.due_date || null,
      notes: form.notes || null,
    });
  }

  async function handleDelete() {
    try {
      await apiJson(`/api/orders/${params.id}`, { method: "DELETE" });
      router.push("/orders");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete.");
    }
  }

  if (loading || (!order && !error)) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <p className="text-gray-400">{error || "Loading…"}</p>
      </main>
    );
  }
  if (!order || !form) {
    return (
      <main className="flex min-h-dvh items-center justify-center px-6 text-center">
        <p className="text-gray-400">{error || "Order not found."}</p>
      </main>
    );
  }

  return (
    <main className="px-4 pt-6">
      <button onClick={() => router.back()} className="mb-3 text-sm text-gray-500">
        ← Back
      </button>
      <h1 className="text-2xl font-bold">{order.customer_name}</h1>
      <p className="text-lg text-gray-500">{formatMoney(order.total, order.currency)}</p>

      {/* One-tap status toggles */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        <button
          onClick={() => patch({ is_paid: !order.is_paid })}
          disabled={saving}
          className={`rounded-2xl py-3.5 font-bold ${
            order.is_paid
              ? "bg-green-600 text-white"
              : "border-2 border-green-600 text-green-700 dark:text-green-400"
          }`}
        >
          {order.is_paid ? "✓ Paid" : "Mark paid"}
        </button>
        <button
          onClick={() => patch({ is_delivered: !order.is_delivered })}
          disabled={saving}
          className={`rounded-2xl py-3.5 font-bold ${
            order.is_delivered
              ? "bg-blue-600 text-white"
              : "border-2 border-blue-600 text-blue-700 dark:text-blue-400"
          }`}
        >
          {order.is_delivered ? "✓ Delivered" : "Mark delivered"}
        </button>
      </div>

      {error && <p className="mt-3 text-sm text-red-600">{error}</p>}

      <div className="mt-6">
        <h2 className="mb-3 font-semibold text-gray-500">Edit details</h2>
        <OrderForm form={form} setForm={setForm} onSave={handleSave} saving={saving} saveLabel="Save changes" />
      </div>

      <div className="mt-6 border-t border-gray-200 pt-4 dark:border-gray-800">
        {!confirmDelete ? (
          <button onClick={() => setConfirmDelete(true)} className="w-full py-2 text-sm text-red-500">
            Delete this order
          </button>
        ) : (
          <div className="rounded-2xl bg-red-50 p-4 text-center dark:bg-red-900/20">
            <p className="text-sm font-semibold">Delete this order for good?</p>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <button
                onClick={() => setConfirmDelete(false)}
                className="rounded-xl border border-gray-300 py-2.5 text-sm font-semibold dark:border-gray-600"
              >
                Keep it
              </button>
              <button
                onClick={handleDelete}
                className="rounded-xl bg-red-600 py-2.5 text-sm font-bold text-white"
              >
                Delete
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
