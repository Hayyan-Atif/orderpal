"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { apiJson } from "@/lib/api";
import type { OrdersResponse } from "@/lib/types";
import { useSession } from "@/lib/use-session";
import OrderForm, { emptyForm, type OrderFormData } from "@/components/OrderForm";
import Paywall, { DailyLimitNotice } from "@/components/Paywall";

export default function NewOrderPage() {
  const { session, loading } = useSession();
  const router = useRouter();
  const [defaultCurrency, setDefaultCurrency] = useState("USD");
  const [message, setMessage] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [extractError, setExtractError] = useState("");
  const [form, setForm] = useState<OrderFormData | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [showPaywall, setShowPaywall] = useState(false);
  const [showDaily, setShowDaily] = useState(false);
  const [sourceLanguage, setSourceLanguage] = useState<string | null>(null);

  useEffect(() => {
    if (!session) return;
    apiJson<OrdersResponse>("/api/orders")
      .then((d) => setDefaultCurrency(d.profile.default_currency))
      .catch(() => {});
  }, [session]);

  async function handleExtract() {
    if (!message.trim()) return;
    setExtracting(true);
    setExtractError("");
    try {
      const data = await apiJson<{ extracted: Record<string, unknown> }>("/api/extract", {
        method: "POST",
        body: JSON.stringify({ text: message }),
      });
      const ex = data.extracted;
      const items = Array.isArray(ex.items) && ex.items.length > 0
        ? (ex.items as { name?: string; qty?: number; price?: number }[]).map((i) => ({
            name: String(i.name ?? ""),
            qty: Number(i.qty ?? 1) || 1,
            price: Number(i.price ?? 0) || 0,
          }))
        : [{ name: "", qty: 1, price: 0 }];
      const total =
        typeof ex.total === "number"
          ? ex.total
          : items.reduce((s, i) => s + i.qty * i.price, 0);
      setSourceLanguage(typeof ex.language === "string" ? ex.language : null);
      setForm({
        customer_name: typeof ex.customer_name === "string" ? ex.customer_name : "",
        customer_phone: typeof ex.phone === "string" ? ex.phone : "",
        items,
        total,
        currency: typeof ex.currency === "string" ? ex.currency : defaultCurrency,
        due_date: typeof ex.due_date === "string" ? ex.due_date : "",
        notes: typeof ex.notes === "string" ? ex.notes : "",
      });
    } catch (e) {
      setExtractError(
        e instanceof Error ? e.message : "AI extraction failed. Fill in the order manually below."
      );
      setForm(emptyForm(defaultCurrency));
    } finally {
      setExtracting(false);
    }
  }

  async function handleSave() {
    if (!form || !form.customer_name.trim()) return;
    setSaving(true);
    setSaveError("");
    try {
      await apiJson("/api/orders", {
        method: "POST",
        body: JSON.stringify({
          customer_name: form.customer_name,
          customer_phone: form.customer_phone,
          items: form.items.filter((i) => i.name.trim()),
          total: form.total,
          currency: form.currency,
          due_date: form.due_date || null,
          notes: form.notes,
          source_message: message || null,
          source_language: sourceLanguage,
        }),
      });
      router.push("/orders");
    } catch (e) {
      const err = e as Error & { code?: string };
      if (err.code === "free_limit") setShowPaywall(true);
      else if (err.code === "daily_limit") setShowDaily(true);
      else setSaveError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <p className="text-gray-400">Loading…</p>
      </main>
    );
  }

  return (
    <main className="px-4 pt-6">
      <h1 className="mb-4 text-2xl font-bold">New Order</h1>

      {!form ? (
        <div className="space-y-3">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Paste the customer&apos;s WhatsApp message and AI will pull out the order details.
            Works in any language.
          </p>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={"Hi! I'd like to order 2 chocolate cakes for Friday. My name is Ayesha, total 3000 Rs…"}
            className="min-h-40 w-full rounded-2xl border border-gray-300 p-4 dark:border-gray-700 dark:bg-gray-800"
          />
          {extractError && <p className="text-sm text-amber-600">{extractError}</p>}
          <button
            onClick={handleExtract}
            disabled={extracting || !message.trim()}
            className="w-full rounded-2xl bg-brand-600 py-4 text-lg font-bold text-white shadow-lg shadow-brand-600/30 disabled:opacity-50"
          >
            {extracting ? "Reading message…" : "✨ Extract order details"}
          </button>
          <button
            onClick={() => setForm(emptyForm(defaultCurrency))}
            className="w-full py-2 text-sm font-semibold text-brand-600"
          >
            or add the order manually →
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="rounded-xl bg-brand-50 p-3 text-sm text-brand-800 dark:bg-brand-700/20 dark:text-brand-100">
            Check the details below and fix anything before saving.
          </div>
          {saveError && <p className="text-sm text-red-600">{saveError}</p>}
          <OrderForm form={form} setForm={setForm} onSave={handleSave} saving={saving} saveLabel="Save order" />
          <button
            onClick={() => { setForm(null); setSaveError(""); }}
            className="w-full py-2 text-sm text-gray-500"
          >
            ← Back to message
          </button>
        </div>
      )}

      {showPaywall && <Paywall onClose={() => setShowPaywall(false)} />}
      {showDaily && <DailyLimitNotice onClose={() => setShowDaily(false)} />}
    </main>
  );
}
