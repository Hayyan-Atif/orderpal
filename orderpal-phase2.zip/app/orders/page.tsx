"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { apiJson } from "@/lib/api";
import { config } from "@/lib/config";
import { formatMoney } from "@/lib/currencies";
import type { Order, OrdersResponse } from "@/lib/types";
import { useSession } from "@/lib/use-session";
import Paywall, { DailyLimitNotice, OwedHeader } from "@/components/Paywall";

type Filter = "all" | "unpaid" | "todeliver" | "completed";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "unpaid", label: "Unpaid" },
  { id: "todeliver", label: "To Deliver" },
  { id: "completed", label: "Completed" },
];

function matches(o: Order, f: Filter): boolean {
  if (f === "all") return true;
  if (f === "unpaid") return !o.is_paid;
  if (f === "todeliver") return !o.is_delivered;
  return o.is_paid && o.is_delivered;
}

export default function OrdersPage() {
  const { session, loading } = useSession();
  const router = useRouter();
  const [data, setData] = useState<OrdersResponse | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [err, setErr] = useState("");
  const [showPaywall, setShowPaywall] = useState(false);
  const [showDaily, setShowDaily] = useState(false);

  useEffect(() => {
    if (!session) return;
    apiJson<OrdersResponse>("/api/orders")
      .then(setData)
      .catch((e: Error) => setErr(e.message));
  }, [session]);

  const filtered = useMemo(
    () => (data?.orders ?? []).filter((o) => matches(o, filter)),
    [data, filter]
  );

  const owed = useMemo(() => {
    const t: Record<string, number> = {};
    for (const o of data?.orders ?? []) {
      if (!o.is_paid) t[o.currency] = (t[o.currency] ?? 0) + Number(o.total);
    }
    return t;
  }, [data]);

  function handleNewOrder() {
    if (!data) return;
    const paid =
      (data.effectivePlan ?? data.profile.plan) === "active" ||
      (data.effectivePlan ?? data.profile.plan) === "past_due";
    if (!paid && data.freeUsed >= data.freeLimit) {
      setShowPaywall(true);
      return;
    }
    if (data.dailyUsed >= data.dailyLimit) {
      setShowDaily(true);
      return;
    }
    router.push("/orders/new");
  }

  if (loading || !data) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <p className="text-gray-400">{err || "Loading…"}</p>
      </main>
    );
  }

  const paid =
    (data.effectivePlan ?? data.profile.plan) === "active" ||
    (data.effectivePlan ?? data.profile.plan) === "past_due";
  const freeLeft = data.freeLimit - data.freeUsed;

  return (
    <main className="px-4 pt-6">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Orders</h1>
        <span className="text-xs text-gray-400">
          {data.dailyUsed}/{data.dailyLimit} today
        </span>
      </div>

      <OwedHeader totals={owed} />

      {!paid && (
        <div
          className={`mt-3 rounded-xl px-4 py-2.5 text-sm ${
            freeLeft <= 3
              ? "bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-100"
              : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300"
          }`}
        >
          {freeLeft <= 3 ? (
            <>⚠️ Only <b>{freeLeft}</b> of your {data.freeLimit} free orders left.</>
          ) : (
            <>{data.freeUsed} of {data.freeLimit} free orders used.</>
          )}
        </div>
      )}

      <button
        onClick={handleNewOrder}
        className="mt-4 w-full rounded-2xl bg-brand-600 py-4 text-lg font-bold text-white shadow-lg shadow-brand-600/30 active:scale-[0.98]"
      >
        ＋ New Order
      </button>

      <Link
        href="/reminders"
        className="mt-3 block rounded-2xl border border-gray-200 bg-white py-3 text-center text-sm font-semibold dark:border-gray-800 dark:bg-gray-900"
      >
        💬 Payment reminders (unpaid orders)
      </Link>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold ${
              filter === f.id
                ? "bg-gray-900 text-white dark:bg-white dark:text-gray-900"
                : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-3 space-y-3">
        {filtered.length === 0 && (
          <p className="py-10 text-center text-sm text-gray-400">
            No orders here yet. Tap “New Order” to add your first one.
          </p>
        )}
        {filtered.map((o) => (
          <Link
            key={o.id}
            href={`/orders/${o.id}`}
            className="block rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate font-semibold">{o.customer_name}</p>
                <p className="truncate text-xs text-gray-400">
                  {o.items.map((i) => `${i.qty}× ${i.name}`).join(", ") || "No items"}
                </p>
              </div>
              <p className="shrink-0 font-bold">{formatMoney(o.total, o.currency)}</p>
            </div>
            <div className="mt-2 flex gap-2">
              <span
                className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                  o.is_paid
                    ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                }`}
              >
                {o.is_paid ? "Paid" : "Unpaid"}
              </span>
              <span
                className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                  o.is_delivered
                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                    : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300"
                }`}
              >
                {o.is_delivered ? "Delivered" : "To deliver"}
              </span>
              {o.due_date && (
                <span className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                  📅 {o.due_date}
                </span>
              )}
            </div>
          </Link>
        ))}
      </div>

      {showPaywall && <Paywall onClose={() => setShowPaywall(false)} />}
      {showDaily && <DailyLimitNotice onClose={() => setShowDaily(false)} />}
    </main>
  );
}
