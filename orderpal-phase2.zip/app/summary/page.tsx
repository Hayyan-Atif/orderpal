"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { apiJson } from "@/lib/api";
import { formatMoney } from "@/lib/currencies";
import type { OrdersResponse } from "@/lib/types";
import { weeklySummary } from "@/lib/summary";
import { useSession } from "@/lib/use-session";

function moneyList(totals: Record<string, number>): string {
  const entries = Object.entries(totals).filter(([, v]) => v > 0);
  if (entries.length === 0) return "—";
  return entries.map(([cur, amt]) => formatMoney(amt, cur)).join("  ·  ");
}

export default function SummaryPage() {
  const { session, loading } = useSession();
  const [data, setData] = useState<OrdersResponse | null>(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!session) return;
    apiJson<OrdersResponse>("/api/orders")
      .then(setData)
      .catch((e: Error) => setErr(e.message));
  }, [session]);

  const summary = useMemo(() => (data ? weeklySummary(data.orders) : null), [data]);

  if (loading || !data || !summary) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <p className="text-gray-400">{err || "Loading…"}</p>
      </main>
    );
  }

  return (
    <main className="px-4 pt-6">
      <h1 className="mb-1 text-2xl font-bold">Weekly Summary</h1>
      <p className="mb-4 text-sm text-gray-500 dark:text-gray-400">
        Last 7 days: {summary.start} → {summary.end}. Computed from your own
        orders only; currencies are never converted or mixed.
      </p>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <p className="text-xs text-gray-400">Orders</p>
          <p className="mt-1 text-2xl font-bold">{summary.orderCount}</p>
        </div>
        <div className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <p className="text-xs text-gray-400">Total value</p>
          <p className="mt-1 text-lg font-bold">{moneyList(summary.totalsByCurrency)}</p>
        </div>
        <div className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <p className="text-xs text-gray-400">Paid this week</p>
          <p className="mt-1 text-lg font-bold text-green-600">{moneyList(summary.paidByCurrency)}</p>
        </div>
        <div className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
          <p className="text-xs text-gray-400">Still unpaid</p>
          <p className="mt-1 text-lg font-bold text-red-600">{moneyList(summary.owedByCurrency)}</p>
        </div>
      </div>

      <section className="mt-4 rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
        <h2 className="font-semibold">New customers this week</h2>
        {summary.newCustomers.length === 0 ? (
          <p className="mt-1 text-sm text-gray-500">None — no first-time customers in the last 7 days.</p>
        ) : (
          <ul className="mt-2 space-y-1">
            {summary.newCustomers.map((n) => (
              <li key={n} className="text-sm">👥 {n}</li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-4 rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
        <h2 className="font-semibold">Top customers this week</h2>
        {summary.topCustomers.length === 0 ? (
          <p className="mt-1 text-sm text-gray-500">No orders in the last 7 days.</p>
        ) : (
          <ul className="mt-2 space-y-1">
            {summary.topCustomers.map((t) => (
              <li key={`${t.name}-${t.currency}`} className="flex justify-between text-sm">
                <span>{t.name}</span>
                <span className="font-semibold">{formatMoney(t.total, t.currency)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <Link
        href="/reminders"
        className="mt-4 block rounded-2xl bg-brand-600 py-3.5 text-center font-semibold text-white"
      >
        💬 Payment reminders →
      </Link>
    </main>
  );
}
