"use client";

import { useEffect, useState } from "react";
import { apiJson } from "@/lib/api";
import { formatMoney } from "@/lib/currencies";
import type { Order } from "@/lib/types";
import { isOverdue } from "@/lib/reminders";
import { useSession } from "@/lib/use-session";

interface RemindersResponse {
  overdue: Order[];
  remindersUsed: number;
  reminderLimit: number;
}

interface DraftState {
  draft: string;
  waLink: string | null;
  phone: string | null;
  fallback: boolean;
}

export default function RemindersPage() {
  const { session, loading } = useSession();
  const [data, setData] = useState<RemindersResponse | null>(null);
  const [err, setErr] = useState("");
  const [drafts, setDrafts] = useState<Record<string, DraftState>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [draftErr, setDraftErr] = useState("");

  useEffect(() => {
    if (!session) return;
    apiJson<RemindersResponse>("/api/reminders")
      .then(setData)
      .catch((e: Error) => setErr(e.message));
  }, [session]);

  async function makeDraft(orderId: string) {
    setBusy(orderId);
    setDraftErr("");
    try {
      const d = await apiJson<DraftState & { remindersUsed: number }>("/api/reminders/draft", {
        method: "POST",
        body: JSON.stringify({ orderId }),
      });
      setDrafts((prev) => ({ ...prev, [orderId]: d }));
      setData((prev) =>
        prev ? { ...prev, remindersUsed: d.remindersUsed } : prev
      );
    } catch (e) {
      setDraftErr(e instanceof Error ? e.message : "Could not draft a reminder.");
    } finally {
      setBusy(null);
    }
  }

  if (loading || !data) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <p className="text-gray-400">{err || "Loading…"}</p>
      </main>
    );
  }

  return (
    <main className="px-4 pt-6">
      <h1 className="mb-1 text-2xl font-bold">Payment reminders</h1>
      <p className="mb-4 text-sm text-gray-500 dark:text-gray-400">
        Unpaid orders, most overdue first. Draft a message, edit it, then open
        WhatsApp yourself — OrderPal never sends a message for you.
        Drafts today: {data.remindersUsed}/{data.reminderLimit}.
      </p>
      {draftErr && <p className="mb-3 rounded-xl bg-red-50 p-3 text-sm text-red-700">{draftErr}</p>}

      {data.overdue.length === 0 && (
        <p className="py-10 text-center text-sm text-gray-400">
          Nothing unpaid right now. 🎉
        </p>
      )}

      <div className="space-y-3">
        {data.overdue.map((o) => {
          const d = drafts[o.id];
          return (
            <div
              key={o.id}
              className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{o.customer_name}</p>
                  <p className="truncate text-xs text-gray-400">
                    {o.items.map((i) => `${i.qty}× ${i.name}`).join(", ") || "No items"}
                  </p>
                  {o.due_date && (
                    <p className={`mt-1 text-xs font-semibold ${isOverdue(o) ? "text-red-600" : "text-gray-500"}`}>
                      {isOverdue(o) ? "Overdue — " : ""}due {o.due_date}
                    </p>
                  )}
                </div>
                <p className="shrink-0 font-bold">{formatMoney(o.total, o.currency)}</p>
              </div>

              {!d && (
                <button
                  onClick={() => makeDraft(o.id)}
                  disabled={busy === o.id}
                  className="mt-3 w-full rounded-xl bg-brand-600 py-2.5 text-sm font-semibold text-white disabled:opacity-50"
                >
                  {busy === o.id ? "Drafting…" : "✍️ Draft reminder"}
                </button>
              )}

              {d && (
                <div className="mt-3">
                  <textarea
                    value={d.draft}
                    onChange={(e) =>
                      setDrafts((prev) => ({
                        ...prev,
                        [o.id]: {
                          ...d,
                          draft: e.target.value,
                          waLink: d.phone
                            ? `https://wa.me/${d.phone.replace(/\D/g, "")}?text=${encodeURIComponent(e.target.value)}`
                            : null,
                        },
                      }))
                    }
                    rows={4}
                    className="w-full rounded-xl border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800"
                  />
                  {d.fallback && (
                    <p className="mt-1 text-xs text-gray-400">
                      AI was unavailable, so this is the standard template — edit freely.
                    </p>
                  )}
                  {d.waLink ? (
                    <a
                      href={d.waLink}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-2 block rounded-xl bg-green-600 py-2.5 text-center text-sm font-semibold text-white"
                    >
                      Open in WhatsApp →
                    </a>
                  ) : (
                    <p className="mt-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
                      No phone number on this order, so there is no WhatsApp link.
                      Copy the draft above and send it yourself.
                    </p>
                  )}
                  <button
                    onClick={() => navigator.clipboard?.writeText(d.draft).catch(() => {})}
                    className="mt-2 w-full rounded-xl border border-gray-300 py-2 text-sm font-semibold dark:border-gray-700"
                  >
                    Copy draft
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </main>
  );
}
