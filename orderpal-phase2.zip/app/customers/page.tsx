"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { apiJson } from "@/lib/api";
import { formatMoney } from "@/lib/currencies";
import type { OrdersResponse } from "@/lib/types";
import { deriveCustomers } from "@/lib/customers";
import { useSession } from "@/lib/use-session";

function moneyList(totals: Record<string, number>): string {
  const entries = Object.entries(totals).filter(([, v]) => v > 0);
  if (entries.length === 0) return "—";
  return entries.map(([cur, amt]) => formatMoney(amt, cur)).join("  ·  ");
}

export default function CustomersPage() {
  const { session, loading } = useSession();
  const [data, setData] = useState<OrdersResponse | null>(null);
  const [err, setErr] = useState("");
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    if (!session) return;
    apiJson<OrdersResponse>("/api/orders")
      .then(setData)
      .catch((e: Error) => setErr(e.message));
  }, [session]);

  const customers = useMemo(() => deriveCustomers(data?.orders ?? []), [data]);

  if (loading || !data) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <p className="text-gray-400">{err || "Loading…"}</p>
      </main>
    );
  }

  return (
    <main className="px-4 pt-6">
      <h1 className="mb-1 text-2xl font-bold">Customers</h1>
      <p className="mb-4 text-sm text-gray-500 dark:text-gray-400">
        Built automatically from your orders — no customer is invented here.
        Tap a customer to see their full order history.
      </p>

      {customers.length === 0 && (
        <p className="py-10 text-center text-sm text-gray-400">
          No customers yet. Your first order will create the first one.
        </p>
      )}

      <div className="space-y-3">
        {customers.map((c) => (
          <div
            key={c.key}
            className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900"
          >
            <button
              onClick={() => setOpen(open === c.key ? null : c.key)}
              className="flex w-full items-start justify-between gap-2 text-left"
            >
              <div className="min-w-0">
                <p className="truncate font-semibold">{c.name}</p>
                {c.phone && <p className="text-xs text-gray-400">{c.phone}</p>}
                <p className="mt-1 text-xs text-gray-500">
                  {c.orderCount} order{c.orderCount === 1 ? "" : "s"}
                  {c.unpaidCount > 0 && ` · ${c.unpaidCount} unpaid`}
                </p>
              </div>
              <div className="shrink-0 text-right">
                <p className="text-xs text-gray-400">Still owed</p>
                <p className="font-bold">{moneyList(c.owedByCurrency)}</p>
                <p className="mt-1 text-xs text-gray-500">
                  Paid: {moneyList(c.paidByCurrency)}
                </p>
              </div>
            </button>

            {open === c.key && (
              <div className="mt-3 space-y-2 border-t border-gray-100 pt-3 dark:border-gray-800">
                {c.orders.map((o) => (
                  <Link
                    key={o.id}
                    href={`/orders/${o.id}`}
                    className="flex items-center justify-between gap-2 rounded-xl bg-gray-50 px-3 py-2 dark:bg-gray-800"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm">
                        {o.items.map((i) => `${i.qty}× ${i.name}`).join(", ") || "No items"}
                      </span>
                      <span className="text-xs text-gray-400">
                        {o.created_at.slice(0, 10)}
                        {o.due_date ? ` · due ${o.due_date}` : ""}
                      </span>
                    </span>
                    <span className="shrink-0 text-right">
                      <span className="block text-sm font-semibold">
                        {formatMoney(o.total, o.currency)}
                      </span>
                      <span
                        className={`text-xs font-semibold ${o.is_paid ? "text-green-600" : "text-red-600"}`}
                      >
                        {o.is_paid ? "Paid" : "Unpaid"}
                      </span>
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </main>
  );
}
