"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { apiJson } from "@/lib/api";
import { config } from "@/lib/config";
import { CURRENCIES } from "@/lib/currencies";
import type { OrdersResponse, Subscription } from "@/lib/types";
import { useSession } from "@/lib/use-session";
import { getSupabase } from "@/lib/supabase-client";
import { setThemeChoice } from "@/components/ThemeScript";

type Theme = "light" | "dark" | "system";

export default function SettingsPage() {
  const { session, loading } = useSession();
  const router = useRouter();
  const [data, setData] = useState<OrdersResponse | null>(null);
  const [currency, setCurrency] = useState("USD");
  const [theme, setTheme] = useState<Theme>("system");
  const [saved, setSaved] = useState("");
  const [error, setError] = useState("");
  const [sub, setSub] = useState<Subscription | null>(null);
  const [subInfo, setSubInfo] = useState("");
  const [subBusy, setSubBusy] = useState(false);
  const [gatewayNote, setGatewayNote] = useState("");

  useEffect(() => {
    if (!session) return;
    apiJson<OrdersResponse>("/api/orders")
      .then((d) => {
        setData(d);
        setCurrency(d.profile.default_currency);
        setSub(d.subscription ?? null);
      })
      .catch((e: Error) => setError(e.message));
    apiJson<{ gateway: string; mode: string }>("/api/subscription")
      .then((s) => setGatewayNote(`Payments via ${s.gateway} (${s.mode} mode — see README Phase 2).`))
      .catch(() => {});
    setTheme((localStorage.getItem("orderpal-theme") as Theme) || "system");
  }, [session]);

  async function saveCurrency(code: string) {
    setCurrency(code);
    setSaved("");
    try {
      await apiJson("/api/profile", {
        method: "PATCH",
        body: JSON.stringify({ default_currency: code }),
      });
      setSaved("Saved ✓");
      setTimeout(() => setSaved(""), 2000);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save.");
    }
  }

  function changeTheme(t: Theme) {
    setTheme(t);
    setThemeChoice(t);
  }

  async function signOut() {
    await getSupabase().auth.signOut();
    router.replace("/login");
  }

  if (loading || !data) {
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <p className="text-gray-400">{error || "Loading…"}</p>
      </main>
    );
  }

  const effective = data.effectivePlan ?? data.profile.plan;
  const paid = effective === "active" || effective === "past_due";
  const planLabel =
    effective === "active"
      ? `Pro (${data.profile.plan_interval ?? "active"})`
      : effective === "past_due"
        ? `Pro — payment past due (retry window: 3 attempts over 5 days, then back to free plan)`
        : effective === "canceled"
          ? `Canceled — ${data.freeUsed} of ${data.freeLimit} free orders used`
          : `Free — ${data.freeUsed} of ${data.freeLimit} orders used`;

  async function manage(action: "cancel" | "switch" | "update_card", interval?: "monthly" | "yearly") {
    setSubBusy(true);
    setSubInfo("");
    setError("");
    try {
      const d = await apiJson<{ portalUrl: string | null; message: string }>("/api/subscription/manage", {
        method: "POST",
        body: JSON.stringify({ action, interval }),
      });
      if (d.portalUrl) window.location.href = d.portalUrl;
      else setSubInfo(d.message || "Done.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not manage the subscription.");
    } finally {
      setSubBusy(false);
    }
  }

  async function subscribe(interval: "monthly" | "yearly") {
    setSubBusy(true);
    setError("");
    try {
      const d = await apiJson<{ checkoutUrl: string }>("/api/subscription/checkout", {
        method: "POST",
        body: JSON.stringify({ interval }),
      });
      window.location.href = d.checkoutUrl;
    } catch (e) {
      setError(e instanceof Error ? e.message : "Checkout is not connected yet.");
    } finally {
      setSubBusy(false);
    }
  }

  return (
    <main className="px-4 pt-6">
      <h1 className="mb-5 text-2xl font-bold">Settings</h1>

      <section className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
        <h2 className="font-semibold">Plan</h2>
        <p className="mt-1 text-sm text-gray-500">{planLabel}</p>
        {sub && (
          <p className="mt-1 text-xs text-gray-400">
            Gateway: {sub.gateway} · status: {sub.status}
            {sub.failed_renewal_attempts > 0 && ` · failed renewals: ${sub.failed_renewal_attempts}/3`}
          </p>
        )}
        {gatewayNote && <p className="mt-1 text-xs text-gray-400">{gatewayNote}</p>}
        {data.downgradeDue && (
          <p className="mt-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-800">
            Renewal failed 3 times over 5 days, so this account now follows free-plan rules.
            Your existing orders stay viewable and editable.
          </p>
        )}
        {subInfo && <p className="mt-2 text-sm text-green-600">{subInfo}</p>}
        {paid ? (
          <div className="mt-3 space-y-2">
            <button
              onClick={() => manage("update_card")}
              disabled={subBusy}
              className="w-full rounded-xl border border-gray-300 py-2.5 text-sm font-semibold dark:border-gray-700 disabled:opacity-50"
            >
              Update saved card (gateway&apos;s secure page)
            </button>
            <button
              onClick={() =>
                manage("switch", data.profile.plan_interval === "monthly" ? "yearly" : "monthly")
              }
              disabled={subBusy}
              className="w-full rounded-xl border border-gray-300 py-2.5 text-sm font-semibold dark:border-gray-700 disabled:opacity-50"
            >
              Switch to {data.profile.plan_interval === "monthly" ? "yearly" : "monthly"}
            </button>
            <button
              onClick={() => {
                if (confirm("Cancel your subscription? Your existing orders stay viewable and editable.")) {
                  manage("cancel");
                }
              }}
              disabled={subBusy}
              className="w-full rounded-xl border border-red-200 py-2.5 text-sm font-semibold text-red-600 disabled:opacity-50"
            >
              Cancel subscription
            </button>
            <p className="text-center text-xs text-gray-400">
              Card changes and cancellation go through the gateway — OrderPal never stores card numbers.
            </p>
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              onClick={() => subscribe("monthly")}
              disabled={subBusy}
              className="rounded-xl bg-brand-600 py-2.5 text-sm font-semibold text-white disabled:opacity-50"
            >
              Subscribe ${config.monthlyPriceUSD}/mo
            </button>
            <button
              onClick={() => subscribe("yearly")}
              disabled={subBusy}
              className="rounded-xl bg-brand-600 py-2.5 text-sm font-semibold text-white disabled:opacity-50"
            >
              Subscribe ${config.yearlyPriceUSD}/yr
            </button>
          </div>
        )}
      </section>

      <section className="mt-4 rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
        <h2 className="font-semibold">Default currency</h2>
        <p className="mt-1 text-sm text-gray-500">New orders use this unless you change it.</p>
        <select
          value={currency}
          onChange={(e) => saveCurrency(e.target.value)}
          className="mt-3 w-full rounded-xl border border-gray-300 px-4 py-3 dark:border-gray-700 dark:bg-gray-800"
        >
          {CURRENCIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.code} — {c.name} ({c.symbol})
            </option>
          ))}
        </select>
        {saved && <p className="mt-2 text-sm text-green-600">{saved}</p>}
      </section>

      <section className="mt-4 rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
        <h2 className="font-semibold">Appearance</h2>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {(["light", "dark", "system"] as Theme[]).map((t) => (
            <button
              key={t}
              onClick={() => changeTheme(t)}
              className={`rounded-xl py-2.5 text-sm font-semibold capitalize ${
                theme === t
                  ? "bg-gray-900 text-white dark:bg-white dark:text-gray-900"
                  : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-4 rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
        <h2 className="font-semibold">Account</h2>
        <p className="mt-1 break-all text-sm text-gray-500">{session?.user.email}</p>
        <button
          onClick={signOut}
          className="mt-3 w-full rounded-xl bg-gray-100 py-2.5 text-sm font-semibold text-gray-700 dark:bg-gray-800 dark:text-gray-200"
        >
          Sign out
        </button>
      </section>

      <p className="mt-6 text-center text-xs text-gray-400">
        OrderPal Phase 2 · Prices in config: ${config.monthlyPriceUSD}/mo, ${config.yearlyPriceUSD}/yr
      </p>
    </main>
  );
}
