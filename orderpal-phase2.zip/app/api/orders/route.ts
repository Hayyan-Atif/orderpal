import { getUser, json } from "@/lib/supabase-server";
import { config } from "@/lib/config";
import { startOfTodayUTC } from "@/lib/time";
import { effectivePlan, hasProAccess, isDowngradeDue } from "@/lib/payments/downgrade";
import type { Subscription } from "@/lib/types";

async function loadSubscription(supabase: any, userId: string): Promise<Subscription | null> {
  const { data } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (data as Subscription | null) ?? null;
}

async function loadProfileAndCounts(supabase: any, userId: string) {
  const { data: profile } = await supabase
    .from("profiles")
    .select("id, default_currency, timezone, plan, plan_interval")
    .eq("id", userId)
    .single();

  const { count: totalCount } = await supabase
    .from("orders")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId);

  const tz = profile?.timezone || "UTC";
  const { count: dailyCount } = await supabase
    .from("orders")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .gte("created_at", startOfTodayUTC(tz));

  return {
    profile: profile ?? {
      id: userId,
      default_currency: config.defaultCurrency,
      timezone: "UTC",
      plan: "free",
      plan_interval: null,
    },
    freeUsed: totalCount ?? 0,
    dailyUsed: dailyCount ?? 0,
  };
}

export async function GET(req: Request) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const { data: orders, error: ordersError } = await supabase
    .from("orders")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (ordersError) return json({ error: "Could not load orders." }, 500);

  const counts = await loadProfileAndCounts(supabase, user.id);
  const subscription = await loadSubscription(supabase, user.id);
  return json({
    orders: orders ?? [],
    profile: counts.profile,
    freeUsed: counts.freeUsed,
    freeLimit: config.freeOrderLimit,
    dailyUsed: counts.dailyUsed,
    dailyLimit: config.dailyOrderLimit,
    subscription,
    effectivePlan: effectivePlan(counts.profile.plan, subscription),
    downgradeDue: isDowngradeDue(subscription),
  });
}

export async function POST(req: Request) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const body = (await req.json().catch(() => null)) as {
    customer_name?: string;
    customer_phone?: string;
    items?: { name: string; qty: number; price: number }[];
    total?: number;
    currency?: string;
    due_date?: string | null;
    notes?: string;
    source_message?: string;
    source_language?: string;
  } | null;
  if (!body || !body.customer_name?.trim()) {
    return json({ error: "Customer name is required." }, 400);
  }

  // ---- Server-side limit enforcement (cannot be bypassed from the app) ----
  const { profile, freeUsed, dailyUsed } = await loadProfileAndCounts(supabase, user.id);
  const subscription = await loadSubscription(supabase, user.id);
  // Pro access = active, or past_due inside the 3-attempt / 5-day retry
  // window (grace). Once downgraded, the account follows free-plan rules.
  const isPaid = hasProAccess(profile.plan, subscription);
  const downgraded = isDowngradeDue(subscription);

  if (!isPaid && freeUsed >= config.freeOrderLimit) {
    if (downgraded) {
      return json(
        {
          code: "free_limit",
          error:
            "Your subscription renewal failed 3 times over 5 days, so your account is back on the free plan. Subscribe again to keep tracking unlimited orders — your existing orders stay viewable and editable.",
        },
        403
      );
    }
    return json(
      {
        code: "free_limit",
        error: `You've used your ${config.freeOrderLimit} free orders. Subscribe to keep tracking unlimited orders.`,
      },
      403
    );
  }
  if (dailyUsed >= config.dailyOrderLimit) {
    return json(
      {
        code: "daily_limit",
        error: `You've reached today's limit of ${config.dailyOrderLimit} orders. It resets tomorrow.`,
      },
      403
    );
  }
  // --------------------------------------------------------------------------

  const items = (body.items ?? []).filter((i) => i.name?.trim());
  const total =
    typeof body.total === "number"
      ? body.total
      : items.reduce((s, i) => s + Number(i.qty || 0) * Number(i.price || 0), 0);

  const { data, error: insertError } = await supabase
    .from("orders")
    .insert({
      user_id: user.id,
      customer_name: body.customer_name.trim(),
      customer_phone: body.customer_phone?.trim() || null,
      items,
      total,
      currency: body.currency || profile.default_currency,
      due_date: body.due_date || null,
      notes: body.notes?.trim() || null,
      source_message: body.source_message || null,
      source_language: body.source_language || null,
    })
    .select()
    .single();

  if (insertError) return json({ error: "Could not save the order." }, 500);
  return json({ order: data }, 201);
}
