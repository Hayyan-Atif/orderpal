import { getUser, json } from "@/lib/supabase-server";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  // Only allow known fields to be updated.
  const allowed = [
    "customer_name",
    "customer_phone",
    "items",
    "total",
    "currency",
    "due_date",
    "notes",
    "is_paid",
    "is_delivered",
  ];
  const patch: Record<string, unknown> = {};
  for (const key of allowed) {
    if (key in body) patch[key] = body[key];
  }
  if (Object.keys(patch).length === 0) {
    return json({ error: "Nothing to update." }, 400);
  }

  const { data, error: updateError } = await supabase
    .from("orders")
    .update(patch)
    .eq("id", params.id)
    .eq("user_id", user.id) // RLS also enforces this
    .select()
    .single();

  if (updateError) return json({ error: "Could not update the order." }, 500);
  return json({ order: data });
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const { error: deleteError } = await supabase
    .from("orders")
    .delete()
    .eq("id", params.id)
    .eq("user_id", user.id);

  if (deleteError) return json({ error: "Could not delete the order." }, 500);
  return json({ ok: true });
}
