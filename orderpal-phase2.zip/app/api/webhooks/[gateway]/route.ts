import { json } from "@/lib/supabase-server";
import { serviceClient } from "@/lib/supabase-service";
import { verifyWebhookSignature, webhookSecretFor } from "@/lib/payments/webhook";
import { safepayGateway } from "@/lib/payments/safepay";
import { payproGateway } from "@/lib/payments/paypro";

/**
 * POST /api/webhooks/safepay  and  /api/webhooks/paypro
 *
 * Order of operations (non-negotiable):
 *  1. Verify the HMAC signature against the gateway's webhook secret.
 *     Unverified or secret-less requests are rejected — no event is applied.
 *  2. Dedupe by event id (subscription_events) so a redelivery does not
 *     double-count a failed renewal.
 *  3. Apply the normalised event via the service-role client (webhooks
 *     have no user session). Without SUPABASE_SERVICE_ROLE_KEY the event
 *     is refused rather than applied unsafely.
 *
 * Events applied:
 *  - subscription_active  -> plan active, renewal counters reset
 *  - payment_failed       -> plan past_due, failed_renewal_attempts + 1,
 *                            first_failed_at set on the first failure
 *  - subscription_canceled-> plan canceled
 * The 3-attempt / 5-day downgrade itself is computed by
 * lib/payments/downgrade.ts at order-creation time (see README).
 */
export async function POST(
  req: Request,
  { params }: { params: { gateway: string } }
) {
  const gateway = params.gateway === "paypro" ? "paypro" : params.gateway === "safepay" ? "safepay" : null;
  if (!gateway) return json({ error: "Unknown gateway." }, 404);

  const rawBody = await req.text();
  const signature =
    req.headers.get("x-safepay-signature") ??
    req.headers.get("x-paypro-signature") ??
    req.headers.get("x-signature") ??
    req.headers.get("x-webhook-signature");
  if (!verifyWebhookSignature({ rawBody, signatureHeader: signature, secret: webhookSecretFor(gateway) })) {
    return json({ error: "Invalid webhook signature." }, 401);
  }

  let body: Record<string, unknown>;
  try {
    body = JSON.parse(rawBody) as Record<string, unknown>;
  } catch {
    return json({ error: "Invalid webhook body." }, 400);
  }

  const adapter = gateway === "paypro" ? payproGateway : safepayGateway;
  const event = adapter.normaliseWebhook(body);
  if (event.kind === "unknown") {
    return json({ ok: true, ignored: true });
  }

  const svc = serviceClient();
  if (!svc) {
    return json(
      { error: "Webhook service key is not configured. Event was verified but NOT applied." },
      503
    );
  }

  // Dedupe (only when the gateway supplies an event id).
  if (event.eventId) {
    const { data: seen } = await svc
      .from("subscription_events")
      .select("id")
      .eq("gateway", gateway)
      .eq("event_id", event.eventId)
      .maybeSingle();
    if (seen) return json({ ok: true, duplicate: true });
    await svc.from("subscription_events").insert({
      gateway,
      event_id: event.eventId,
      event_type: String(body.event_type ?? body.type ?? body.event ?? "unknown"),
      payload: body,
    });
  }

  // Resolve the user: explicit user id first, then gateway customer id.
  let userId = event.userId;
  if (!userId && event.gatewayCustomerId) {
    const { data: sub } = await svc
      .from("subscriptions")
      .select("user_id")
      .eq("gateway", gateway)
      .eq("gateway_customer_id", event.gatewayCustomerId)
      .maybeSingle();
    userId = sub?.user_id ?? null;
  }
  if (!userId) return json({ error: "Could not identify the user for this event." }, 400);

  const { data: existing } = await svc
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();

  const now = new Date().toISOString();
  if (event.kind === "subscription_active") {
    const row = {
      user_id: userId,
      gateway,
      gateway_customer_id: event.gatewayCustomerId ?? existing?.gateway_customer_id ?? null,
      gateway_subscription_id: event.gatewaySubscriptionId ?? existing?.gateway_subscription_id ?? null,
      plan_interval: event.planInterval ?? existing?.plan_interval ?? null,
      status: "active",
      failed_renewal_attempts: 0,
      first_failed_at: null,
      last_failed_at: null,
      current_period_end: event.currentPeriodEnd ?? existing?.current_period_end ?? null,
      updated_at: now,
    };
    if (existing) await svc.from("subscriptions").update(row).eq("id", existing.id);
    else await svc.from("subscriptions").insert(row);
    await svc
      .from("profiles")
      .update({ plan: "active", plan_interval: row.plan_interval })
      .eq("id", userId);
  } else if (event.kind === "payment_failed") {
    const attempts = (existing?.failed_renewal_attempts ?? 0) + 1;
    const row = {
      user_id: userId,
      gateway,
      gateway_customer_id: event.gatewayCustomerId ?? existing?.gateway_customer_id ?? null,
      gateway_subscription_id: event.gatewaySubscriptionId ?? existing?.gateway_subscription_id ?? null,
      plan_interval: existing?.plan_interval ?? null,
      status: "past_due",
      failed_renewal_attempts: attempts,
      first_failed_at: existing?.first_failed_at ?? now,
      last_failed_at: now,
      updated_at: now,
    };
    if (existing) await svc.from("subscriptions").update(row).eq("id", existing.id);
    else await svc.from("subscriptions").insert(row);
    await svc.from("profiles").update({ plan: "past_due" }).eq("id", userId);
  } else if (event.kind === "subscription_canceled") {
    if (existing) {
      await svc
        .from("subscriptions")
        .update({ status: "canceled", updated_at: now })
        .eq("id", existing.id);
    } else {
      await svc.from("subscriptions").insert({
        user_id: userId,
        gateway,
        status: "canceled",
      });
    }
    await svc.from("profiles").update({ plan: "canceled" }).eq("id", userId);
  }

  return json({ ok: true });
}
