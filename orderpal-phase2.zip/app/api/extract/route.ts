import Anthropic from "@anthropic-ai/sdk";
import { getUser, json } from "@/lib/supabase-server";

const SYSTEM_PROMPT = `You extract order details from a customer's WhatsApp message.
The message can be in ANY language. Reply with ONLY a JSON object, no other text.

JSON shape:
{
  "customer_name": "buyer's name if mentioned, otherwise null",
  "phone": "phone number if present, otherwise null",
  "items": [{"name": "item name", "qty": 1, "price": 0}],
  "total": 0,
  "currency": "3-letter code like USD, PKR, INR if you can tell from symbols or words, otherwise null",
  "due_date": "YYYY-MM-DD if a delivery/due date is mentioned, otherwise null",
  "notes": "anything else relevant (address, customization, etc.) or null",
  "language": "BCP-47 language code of the message, e.g. en, ur, es, ar"
}

Rules:
- qty defaults to 1 when not stated. price defaults to 0 when not stated.
- total: use the stated total if given, otherwise sum qty*price.
- Keep item names short and in the message's original language.
- Never invent details that are not in the message; use null when unsure.`;

function extractJson(text: string): Record<string, unknown> | null {
  const cleaned = text.replace(/```json|```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) return null;
  try {
    return JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

export async function POST(req: Request) {
  const { user, error } = await getUser(req);
  if (!user) return json({ error }, 401);
  if (!process.env.ANTHROPIC_API_KEY) {
    return json(
      { code: "ai_not_configured", error: "AI extraction is not set up yet. You can add the order manually." },
      503
    );
  }

  const { text } = (await req.json().catch(() => ({}))) as { text?: string };
  if (!text?.trim()) return json({ error: "Paste a message first." }, 400);
  if (text.length > 4000) return json({ error: "Message is too long. Keep it under 4000 characters." }, 400);

  try {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const message = await client.messages.create({
      model: process.env.ANTHROPIC_MODEL || "claude-haiku-4-5",
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: text.slice(0, 4000) }],
    });
    const block = message.content.find((b) => b.type === "text");
    const parsed = block && block.type === "text" ? extractJson(block.text) : null;
    if (!parsed) {
      return json(
        { code: "ai_failed", error: "I couldn't read that message. Please fill in the order manually." },
        502
      );
    }
    return json({ extracted: parsed });
  } catch (e) {
    console.error("Extraction failed:", e);
    return json(
      { code: "ai_failed", error: "AI extraction failed. Please fill in the order manually." },
      502
    );
  }
}
