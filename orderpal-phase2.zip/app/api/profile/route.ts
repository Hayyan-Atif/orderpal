import { getUser, json } from "@/lib/supabase-server";

export async function PATCH(req: Request) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const body = (await req.json().catch(() => ({}))) as {
    default_currency?: string;
    timezone?: string;
  };

  const patch: Record<string, string> = {};
  if (typeof body.default_currency === "string" && /^[A-Z]{3}$/.test(body.default_currency)) {
    patch.default_currency = body.default_currency;
  }
  if (typeof body.timezone === "string" && body.timezone.length < 64) {
    patch.timezone = body.timezone;
  }
  if (Object.keys(patch).length === 0) {
    return json({ error: "Nothing to update." }, 400);
  }

  const { data, error: updateError } = await supabase
    .from("profiles")
    .update(patch)
    .eq("id", user.id)
    .select()
    .single();

  if (updateError) return json({ error: "Could not update settings." }, 500);
  return json({ profile: data });
}
