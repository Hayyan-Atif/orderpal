import Anthropic from "@anthropic-ai/sdk";
import { getUser, json } from "@/lib/supabase-server";
import { config } from "@/lib/config";
import { startOfTodayUTC } from "@/lib/time";
import { fallbackDraft, waLink } from "@/lib/reminders";

const SYSTEM_PROMPT = `You write a short, polite payment-reminder message for a small home seller to send a customer on WhatsApp.
Reply with ONLY the message text, no quotes, no explanation, no other text.
Rules:
- Keep it under 50 words, warm and friendly, never threatening or shaming.
- Use the customer's name, the items, the amount and currency, and the due date if given.
- Write it in the customer's language if one is given, otherwise English.
- Never invent a payment link, bank detail, or deadline that is not given.`;

/**
 * POST { orderId } -> { draft, waLink, phone, fallback }
 * Server-side 50/day limit (config.dailyReminderLimit), counted in
 * reminder_logs and reset at the user's local midnight. The draft is
 * returned for the seller to edit — nothing is sent to WhatsApp here.
 */
export async function POST(req: Request) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const { orderId } = (await req.json().catch(() => ({}))) as { orderId?: string };
  if (!orderId) return json({ error: "Order id is required." }, 400);

  const { data: order, error: orderError } = await supabase
    .from("orders")
    .select("*")
    .eq("id", orderId)
    .eq("user_id", user.id)
    .single();
  if (orderError || !order) return json({ error: "Order not found." }, 404);
  if (order.is_paid) return json({ error: "That order is already paid." }, 400);

  const { data: profile } = await supabase
    .from("profiles")
    .select("timezone")
    .eq("id", user.id)
    .single();
  const { count } = await supabase
    .from("reminder_logs")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id)
    .gte("created_at", startOfTodayUTC(profile?.timezone || "UTC"));
  if ((count ?? 0) >= config.dailyReminderLimit) {
    return json(
      {
        code: "reminder_limit",
        error: `You've reached today's limit of ${config.dailyReminderLimit} reminder drafts. It resets tomorrow.`,
      },
      429
    );
  }

  let draft = fallbackDraft(order);
  let fallback = true;
  if (process.env.ANTHROPIC_API_KEY) {
    try {
      const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
      const message = await client.messages.create({
        model: process.env.ANTHROPIC_MODEL || "claude-haiku-4-5",
        max_tokens: 256,
        system: SYSTEM_PROMPT,
        messages: [
          {
            role: "user",
            content: JSON.stringify({
              customer_name: order.customer_name,
              items: order.items,
              total: order.total,
              currency: order.currency,
              due_date: order.due_date,
              language: order.source_language ?? null,
            }),
          },
        ],
      });
      const block = message.content.find((b) => b.type === "text");
      if (block && block.type === "text" && block.text.trim()) {
        draft = block.text.trim();
        fallback = false;
      }
    } catch (e) {
      console.error("Reminder draft failed, using fallback:", e);
    }
  }

  // Log the draft (best-effort if the migration has not been run yet).
  await supabase.from("reminder_logs").insert({
    user_id: user.id,
    order_id: order.id,
    draft,
  });

  return json({
    draft,
    waLink: waLink(order.customer_phone, draft),
    phone: order.customer_phone,
    fallback,
    remindersUsed: (count ?? 0) + 1,
    reminderLimit: config.dailyReminderLimit,
  });
}
