import { getUser, json } from "@/lib/supabase-server";
import { config } from "@/lib/config";
import { startOfTodayUTC } from "@/lib/time";
import { overdueOrders } from "@/lib/reminders";

/** Overdue / unpaid view + today's reminder-draft usage (server-counted). */
export async function GET(req: Request) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const { data: profile } = await supabase
    .from("profiles")
    .select("timezone")
    .eq("id", user.id)
    .single();
  const { data: orders, error: ordersError } = await supabase
    .from("orders")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });
  if (ordersError) return json({ error: "Could not load orders." }, 500);

  // reminder_logs may not exist until the Phase 2 migration is run.
  const { count } = await supabase
    .from("reminder_logs")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id)
    .gte("created_at", startOfTodayUTC(profile?.timezone || "UTC"));

  return json({
    overdue: overdueOrders(orders ?? []),
    remindersUsed: count ?? 0,
    reminderLimit: config.dailyReminderLimit,
  });
}
