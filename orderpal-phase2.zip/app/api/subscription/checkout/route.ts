import { getUser, json } from "@/lib/supabase-server";
import { config } from "@/lib/config";
import { activeGateway, paymentMode } from "@/lib/payments/index";
import { GatewayNotConfiguredError } from "@/lib/payments/types";

/**
 * POST { interval: "monthly" | "yearly" } -> { checkoutUrl }
 * Creates a gateway-hosted checkout session. With the current
 * sandbox/stub adapters this returns 503 gateway_not_configured — it
 * never fabricates a checkout URL and never touches a card number.
 * Sandbox-gated: live mode is refused here until PAYMENT_MODE=live AND
 * verified gateway keys are present (the stub refuses either way today).
 */
export async function POST(req: Request) {
  const { user, error } = await getUser(req);
  if (!user) return json({ error }, 401);

  const { interval } = (await req.json().catch(() => ({}))) as {
    interval?: string;
  };
  if (interval !== "monthly" && interval !== "yearly") {
    return json({ error: "Choose monthly or yearly." }, 400);
  }
  if (paymentMode() === "live") {
    return json(
      {
        code: "gateway_not_configured",
        error: "Live payments are not connected yet. Connect the gateway in sandbox first.",
      },
      503
    );
  }

  const amountUSD = interval === "monthly" ? config.monthlyPriceUSD : config.yearlyPriceUSD;
  try {
    const result = await activeGateway().createCheckout({
      userId: user.id,
      interval,
      amountUSD,
    });
    return json({ checkoutUrl: result.checkoutUrl });
  } catch (e) {
    if (e instanceof GatewayNotConfiguredError) {
      return json({ code: e.code, error: e.message }, 503);
    }
    console.error("Checkout failed:", e);
    return json({ error: "Could not start checkout. Try again." }, 502);
  }
}
