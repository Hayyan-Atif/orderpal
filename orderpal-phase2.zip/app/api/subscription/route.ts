import { getUser, json } from "@/lib/supabase-server";
import { effectivePlan, isDowngradeDue } from "@/lib/payments/downgrade";
import { activeGateway, gatewayFromEnv, paymentMode } from "@/lib/payments/index";
import type { Subscription } from "@/lib/types";

/** Current subscription state for Settings / Paywall. Never returns secrets. */
export async function GET(req: Request) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, default_currency, timezone, plan, plan_interval")
    .eq("id", user.id)
    .single();
  const { data: subscription } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  const sub = (subscription as Subscription | null) ?? null;
  return json({
    profile: profile ?? null,
    subscription: sub,
    effectivePlan: effectivePlan(profile?.plan ?? "free", sub),
    downgradeDue: isDowngradeDue(sub),
    gateway: gatewayFromEnv(),
    gatewayConfigured: false, // adapters are stub until verified keys exist
    mode: paymentMode(),
    gatewayName: activeGateway().name,
  });
}
