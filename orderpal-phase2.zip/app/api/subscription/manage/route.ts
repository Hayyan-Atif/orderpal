import { getUser, json } from "@/lib/supabase-server";
import { activeGateway } from "@/lib/payments/index";
import { GatewayNotConfiguredError } from "@/lib/payments/types";

/**
 * POST { action: "cancel" | "switch" | "update_card", interval? }
 * Cancel, switch monthly/yearly, or update the saved card — all via the
 * gateway's hosted flow. Nothing here cancels or changes a subscription
 * locally on its own: doing so without the gateway would leave the seller
 * still being charged (or wrongly cut off). With the stub adapters this
 * returns 503 gateway_not_configured until the gateway is connected.
 */
export async function POST(req: Request) {
  const { user, supabase, error } = await getUser(req);
  if (!user || !supabase) return json({ error }, 401);

  const { action, interval } = (await req.json().catch(() => ({}))) as {
    action?: string;
    interval?: string;
  };
  if (action !== "cancel" && action !== "switch" && action !== "update_card") {
    return json({ error: "Unknown manage action." }, 400);
  }
  if (action === "switch" && interval !== "monthly" && interval !== "yearly") {
    return json({ error: "Choose monthly or yearly to switch to." }, 400);
  }

  const { data: subscription } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  try {
    const result = await activeGateway().manage({
      userId: user.id,
      subscriptionId: subscription?.gateway_subscription_id ?? null,
      action,
      interval: action === "switch" ? (interval as "monthly" | "yearly") : undefined,
    });
    return json({ portalUrl: result.portalUrl, message: result.message });
  } catch (e) {
    if (e instanceof GatewayNotConfiguredError) {
      return json({ code: e.code, error: e.message }, 503);
    }
    console.error("Manage subscription failed:", e);
    return json({ error: "Could not manage the subscription. Try again." }, 502);
  }
}
