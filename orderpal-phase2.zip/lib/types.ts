export interface OrderItem {
  name: string;
  qty: number;
  price: number;
}

export interface Order {
  id: string;
  user_id: string;
  customer_name: string;
  customer_phone: string | null;
  items: OrderItem[];
  total: number;
  currency: string;
  due_date: string | null;
  notes: string | null;
  is_paid: boolean;
  is_delivered: boolean;
  source_message: string | null;
  source_language: string | null;
  created_at: string;
}

export interface Profile {
  id: string;
  default_currency: string;
  timezone: string;
  plan: "free" | "active" | "past_due" | "canceled";
  plan_interval: "monthly" | "yearly" | null;
}

export type SubscriptionStatus = "active" | "past_due" | "canceled";

export interface Subscription {
  id: string;
  user_id: string;
  gateway: string;
  gateway_customer_id: string | null;
  gateway_subscription_id: string | null;
  plan_interval: "monthly" | "yearly" | null;
  status: SubscriptionStatus;
  failed_renewal_attempts: number;
  first_failed_at: string | null;
  last_failed_at: string | null;
  current_period_end: string | null;
  created_at: string;
  updated_at: string;
}

/** Derived from the user's own orders — no separate customer records are invented. */
export interface CustomerSummary {
  key: string;
  name: string;
  phone: string | null;
  orderCount: number;
  unpaidCount: number;
  totalsByCurrency: Record<string, number>;
  paidByCurrency: Record<string, number>;
  owedByCurrency: Record<string, number>;
  firstOrderAt: string;
  lastOrderAt: string;
  orders: Order[];
}

export interface WeeklySummary {
  start: string;
  end: string;
  orderCount: number;
  totalsByCurrency: Record<string, number>;
  paidByCurrency: Record<string, number>;
  owedByCurrency: Record<string, number>;
  newCustomers: string[];
  topCustomers: { name: string; total: number; currency: string }[];
}

export interface ReminderDraft {
  orderId: string;
  draft: string;
  waLink: string | null;
  phone: string | null;
}

export interface OrdersResponse {
  orders: Order[];
  profile: Profile;
  freeUsed: number;
  freeLimit: number;
  dailyUsed: number;
  dailyLimit: number;
  subscription?: Subscription | null;
  effectivePlan?: "free" | "active" | "past_due" | "canceled";
  downgradeDue?: boolean;
}
