// ALL business limits and prices live here. Change them in one place.
export const config = {
  /** Free plan: total orders an account can ever create before the paywall. */
  freeOrderLimit: 20,
  /** Every account (free or paid): max new orders per day, resets at local midnight. */
  dailyOrderLimit: 50,
  /** Every account: max AI reminder drafts per day (phase 2 feature). */
  dailyReminderLimit: 50,
  /** Paid plans, USD. */
  monthlyPriceUSD: 15,
  yearlyPriceUSD: 150,
  /** Shown on the paywall next to the yearly plan. */
  yearlyBadge: "2 months free",
  /** Fallback currency for new accounts. */
  defaultCurrency: "USD",
} as const;

export type PlanId = "monthly" | "yearly";
