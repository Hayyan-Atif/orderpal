/**
 * Start of "today" in the user's timezone, returned as an ISO UTC string.
 * The daily order limit resets at local midnight, so we compute midnight
 * in the user's timezone and convert it back to UTC for the DB query.
 */
export function startOfTodayUTC(timeZone: string): string {
  const now = new Date();
  const wall = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  const parts = Object.fromEntries(
    wall.formatToParts(now).map((p) => [p.type, p.value])
  ) as Record<string, string>;
  // The wall-clock reading, interpreted as if it were UTC...
  const wallAsUTC = Date.UTC(
    Number(parts.year),
    Number(parts.month) - 1,
    Number(parts.day),
    Number(parts.hour) % 24,
    Number(parts.minute),
    Number(parts.second)
  );
  // ...minus the real instant = this timezone's offset from UTC right now.
  const offsetMs = wallAsUTC - now.getTime();

  const ymd = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
  const [y, m, d] = ymd.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d) - offsetMs).toISOString();
}
