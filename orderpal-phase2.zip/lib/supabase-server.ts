import { createClient, SupabaseClient, User } from "@supabase/supabase-js";

/**
 * Server-side Supabase client bound to the caller's access token.
 * Every API route must go through getUser() so limits and ownership
 * are enforced on the server, never trusted from the front end.
 */
export function serverClient(accessToken: string): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { global: { headers: { Authorization: `Bearer ${accessToken}` } } }
  );
}

export async function getUser(req: Request): Promise<
  | { user: User; supabase: SupabaseClient; error: null }
  | { user: null; supabase: null; error: string }
> {
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return { user: null, supabase: null, error: "Not signed in." };
  const sb = serverClient(token);
  const { data, error } = await sb.auth.getUser();
  if (error || !data.user)
    return { user: null, supabase: null, error: "Session expired. Please sign in again." };
  return { user: data.user, supabase: sb, error: null };
}

export function json(data: unknown, status = 200): Response {
  return Response.json(data, { status });
}
