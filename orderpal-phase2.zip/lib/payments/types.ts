/**
 * Payment-gateway abstraction (Phase 2).
 *
 * The app only ever talks to this interface. Safepay is the first gateway;
 * PayPro is the fallback. Swapping gateways = changing PAYMENT_GATEWAY and
 * providing that gateway's adapter — no app code changes.
 *
 * HONEST STATUS (Oct 2026): both adapters below are SANDBOX/STUB adapters.
 * Safepay's public docs confirm a hosted-checkout + webhook pattern (create
 * a payment tracker, get an auth token, redirect to hosted checkout, confirm
 * via webhook, authenticate with an API-key header), but the exact
 * subscription-creation fields, recurring-billing endpoints, and webhook
 * signature format for a merchant account were NOT verified against a live
 * merchant dashboard, so no live Safepay/PayPro endpoint, test card, or
 * dashboard URL is hard-coded anywhere here. The adapters return
 * "gateway_not_configured" until the merchant supplies verified keys AND
 * the exact fields listed in README §Phase 2. Card numbers are never stored
 * by OrderPal — card entry/update always happens on the gateway's hosted
 * flow, never in this app.
 */
export type GatewayName = "safepay" | "paypro";
export type PlanInterval = "monthly" | "yearly";

export interface CheckoutRequest {
  userId: string;
  interval: PlanInterval;
  amountUSD: number;
}

export interface CheckoutResult {
  checkoutUrl: string;
}

export interface ManageRequest {
  userId: string;
  subscriptionId: string | null;
  action: "cancel" | "switch" | "update_card";
  /** For "switch" only. */
  interval?: PlanInterval;
}

export interface ManageResult {
  /** URL of the gateway's hosted management/card-update flow, if any. */
  portalUrl: string | null;
  message: string;
}

/** Normalised webhook event, after signature verification. */
export interface NormalisedWebhookEvent {
  eventId: string | null;
  /** Merchant's user id, or the gateway customer id to look up. */
  userId: string | null;
  gatewayCustomerId: string | null;
  gatewaySubscriptionId: string | null;
  kind:
    | "subscription_active"
    | "payment_failed"
    | "subscription_canceled"
    | "unknown";
  planInterval: PlanInterval | null;
  currentPeriodEnd: string | null;
}

export interface PaymentGateway {
  name: GatewayName;
  /** Throws / returns an error with code "gateway_not_configured" when the
   *  merchant has not supplied verified sandbox keys for this gateway. */
  createCheckout(req: CheckoutRequest): Promise<CheckoutResult>;
  manage(req: ManageRequest): Promise<ManageResult>;
  /** Parse + normalise a webhook payload AFTER the caller verified its signature. */
  normaliseWebhook(body: Record<string, unknown>): NormalisedWebhookEvent;
}

export class GatewayNotConfiguredError extends Error {
  code = "gateway_not_configured";
  constructor(gateway: GatewayName) {
    super(
      `${gateway} is not connected yet. Connect it in sandbox first (see README, Phase 2 section) — no live payment has been attempted.`
    );
    this.name = "GatewayNotConfiguredError";
  }
}

export function gatewayFromEnv(): GatewayName {
  const g = (process.env.PAYMENT_GATEWAY ?? "safepay").toLowerCase();
  return g === "paypro" ? "paypro" : "safepay";
}

/** Sandbox-gated: live mode is refused until the merchant explicitly opts in
 *  with verified keys. Default is sandbox. */
export function paymentMode(): "sandbox" | "live" {
  return process.env.PAYMENT_MODE === "live" ? "live" : "sandbox";
}
