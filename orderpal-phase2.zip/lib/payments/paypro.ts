import {
  GatewayNotConfiguredError,
  type CheckoutRequest,
  type ManageRequest,
  type NormalisedWebhookEvent,
  type PaymentGateway,
} from "@/lib/payments/types";

/**
 * PayPro fallback adapter — SANDBOX/STUB, same status as Safepay
 * (see lib/payments/types.ts header). Used only if Safepay cannot do
 * international USD cards with recurring billing. No PayPro endpoint,
 * test card, or dashboard URL is hard-coded here.
 *
 * Env vars the real adapter will need:
 *   PAYPRO_API_KEY / PAYPRO_SECRET (sandbox keys first)
 *   PAYPRO_WEBHOOK_SECRET
 */
function notConfigured(): never {
  throw new GatewayNotConfiguredError("paypro");
}

export const payproGateway: PaymentGateway = {
  name: "paypro",
  async createCheckout(_req: CheckoutRequest) {
    if (!process.env.PAYPRO_API_KEY || !process.env.PAYPRO_SECRET) {
      notConfigured();
    }
    notConfigured();
  },
  async manage(_req: ManageRequest) {
    if (!process.env.PAYPRO_API_KEY || !process.env.PAYPRO_SECRET) {
      notConfigured();
    }
    notConfigured();
  },
  normaliseWebhook(body: Record<string, unknown>): NormalisedWebhookEvent {
    // Same generic mapping as Safepay; the merchant confirms PayPro's
    // exact event names in sandbox before going live.
    const rawType = String(
      body.event_type ?? body.type ?? body.event ?? ""
    ).toLowerCase();
    const meta = (body.metadata as Record<string, unknown> | undefined) ?? {};
    const kind: NormalisedWebhookEvent["kind"] =
      rawType.includes("cancel")
        ? "subscription_canceled"
        : rawType.includes("fail") || rawType.includes("past_due")
          ? "payment_failed"
          : rawType.includes("active") ||
              rawType.includes("paid") ||
              rawType.includes("renew") ||
              rawType.includes("created") ||
              rawType.includes("succeed")
            ? "subscription_active"
            : "unknown";
    return {
      eventId: (typeof body.id === "string" ? body.id : null) ?? null,
      userId:
        (typeof body.user_id === "string" ? body.user_id : null) ??
        (typeof meta.user_id === "string" ? meta.user_id : null),
      gatewayCustomerId:
        typeof body.customer_id === "string" ? body.customer_id : null,
      gatewaySubscriptionId:
        typeof body.subscription_id === "string" ? body.subscription_id : null,
      kind,
      planInterval:
        body.plan_interval === "monthly" || body.plan_interval === "yearly"
          ? body.plan_interval
          : null,
      currentPeriodEnd:
        typeof body.current_period_end === "string"
          ? body.current_period_end
          : null,
    };
  },
};
