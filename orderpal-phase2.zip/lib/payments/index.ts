import { gatewayFromEnv, type PaymentGateway } from "@/lib/payments/types";
import { safepayGateway } from "@/lib/payments/safepay";
import { payproGateway } from "@/lib/payments/paypro";

export function activeGateway(): PaymentGateway {
  return gatewayFromEnv() === "paypro" ? payproGateway : safepayGateway;
}

export { gatewayFromEnv, paymentMode } from "@/lib/payments/types";
export type { GatewayName, PlanInterval } from "@/lib/payments/types";
