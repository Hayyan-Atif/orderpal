import type { Subscription } from "@/lib/types";

/**
 * Failed-renewal rule (Phase 2, from the standing spec):
 * retry messaging for up to 3 attempts over 5 days, then downgrade to
 * free-plan rules. Existing orders stay viewable/editable either way;
 * only NEW order creation is blocked once downgraded (and only once the
 * free limit is also reached — same as a free account).
 *
 * "Downgraded" is computed, never silently written: the profile keeps its
 * past_due status so the seller can still see what happened, and the app
 * treats the account as free once the window has elapsed.
 */
export const RENEWAL_MAX_ATTEMPTS = 3;
export const RENEWAL_WINDOW_DAYS = 5;

export function isDowngradeDue(
  sub: Subscription | null,
  now = new Date()
): boolean {
  if (!sub) return false;
  if (sub.status !== "past_due") return false;
  if (sub.failed_renewal_attempts < RENEWAL_MAX_ATTEMPTS) return false;
  if (!sub.first_failed_at) return false;
  const deadline =
    new Date(sub.first_failed_at).getTime() +
    RENEWAL_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  return now.getTime() >= deadline;
}

/** Effective plan for limit enforcement. */
export function effectivePlan(
  profilePlan: string,
  sub: Subscription | null,
  now = new Date()
): "free" | "active" | "past_due" | "canceled" {
  if (profilePlan === "past_due" && isDowngradeDue(sub, now)) return "canceled";
  if (
    profilePlan === "active" ||
    profilePlan === "past_due" ||
    profilePlan === "canceled" ||
    profilePlan === "free"
  ) {
    return profilePlan;
  }
  return "free";
}

/** True when the account may create new orders beyond the free limit. */
export function hasProAccess(
  profilePlan: string,
  sub: Subscription | null,
  now = new Date()
): boolean {
  const eff = effectivePlan(profilePlan, sub, now);
  // past_due inside the retry window keeps access (grace period);
  // active always does; canceled/downgraded and free do not.
  return eff === "active" || (profilePlan === "past_due" && eff === "past_due");
}
