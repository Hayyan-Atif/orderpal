import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Verify a webhook signature BEFORE trusting any event.
 * Generic HMAC-SHA256 over the raw body, compared in constant time.
 * The merchant supplies the exact header name + secret from their gateway
 * dashboard (SAFEPAY_WEBHOOK_SECRET / PAYPRO_WEBHOOK_SECRET, or the shared
 * PAYMENT_WEBHOOK_SECRET). A missing secret or a bad signature = reject;
 * the event is never applied on an unverified request.
 */
export function verifyWebhookSignature(opts: {
  rawBody: string;
  signatureHeader: string | null;
  secret: string | null;
}): boolean {
  const { rawBody, signatureHeader, secret } = opts;
  if (!secret || !signatureHeader) return false;
  // Accept "sha256=<hex>" or a bare hex digest.
  const provided = signatureHeader.replace(/^sha256=/i, "").trim();
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  try {
    const a = Buffer.from(provided, "hex");
    const b = Buffer.from(expected, "hex");
    return a.length === b.length && timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

export function webhookSecretFor(gateway: "safepay" | "paypro"): string | null {
  return (
    process.env.PAYMENT_WEBHOOK_SECRET ??
    (gateway === "safepay"
      ? process.env.SAFEPAY_WEBHOOK_SECRET
      : process.env.PAYPRO_WEBHOOK_SECRET) ??
    null
  );
}
