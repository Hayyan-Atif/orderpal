import {
  GatewayNotConfiguredError,
  type CheckoutRequest,
  type ManageRequest,
  type NormalisedWebhookEvent,
  type PaymentGateway,
} from "@/lib/payments/types";

/**
 * Safepay adapter — SANDBOX/STUB (see lib/payments/types.ts header).
 *
 * What is implemented for real: the interface, the env gating, and webhook
 * normalisation for the generic event shapes a merchant will map once their
 * dashboard's exact event names are confirmed. What is NOT implemented:
 * any call to a Safepay API endpoint, because the exact subscription
 * endpoints/fields were not verified against live Safepay docs or a
 * merchant dashboard. When verified keys + fields exist, replace the
 * stubs below with the real hosted-checkout calls; the rest of the app
 * does not change.
 *
 * Env vars the real adapter will need (none are read as live secrets here):
 *   SAFEPAY_MODE=sandbox (default) | live
 *   SAFEPAY_API_KEY / SAFEPAY_SECRET (sandbox keys first)
 *   SAFEPAY_WEBHOOK_SECRET (for webhook signature verification)
 */
function notConfigured(): never {
  throw new GatewayNotConfiguredError("safepay");
}

function pick(body: Record<string, unknown>, keys: string[]): unknown {
  for (const k of keys) {
    const v = body[k];
    if (typeof v === "string" && v) return v;
  }
  return null;
}

export const safepayGateway: PaymentGateway = {
  name: "safepay",
  async createCheckout(_req: CheckoutRequest) {
    // Stub: no checkout URL is fabricated. The merchant must first supply
    // verified sandbox keys and the exact tracker/checkout fields.
    if (!process.env.SAFEPAY_API_KEY || !process.env.SAFEPAY_SECRET) {
      notConfigured();
    }
    // Keys present but endpoint fields unverified — still refuse to guess.
    notConfigured();
  },
  async manage(_req: ManageRequest) {
    if (!process.env.SAFEPAY_API_KEY || !process.env.SAFEPAY_SECRET) {
      notConfigured();
    }
    notConfigured();
  },
  normaliseWebhook(body: Record<string, unknown>): NormalisedWebhookEvent {
    const rawType = String(
      pick(body, ["event_type", "type", "event"]) ?? ""
    ).toLowerCase();
    const meta =
      (body.metadata as Record<string, unknown> | undefined) ??
      (body.data as Record<string, unknown> | undefined) ??
      {};
    const userId = (pick(body, ["user_id"]) ??
      pick(meta, ["user_id"])) as string | null;
    const gatewayCustomerId = (pick(body, [
      "customer_id",
      "gateway_customer_id",
    ]) ?? pick(meta, ["customer_id"])) as string | null;
    const gatewaySubscriptionId = (pick(body, [
      "subscription_id",
      "gateway_subscription_id",
    ]) ?? pick(meta, ["subscription_id"])) as string | null;
    const intervalRaw = String(
      pick(body, ["plan_interval", "interval"]) ??
        pick(meta, ["plan_interval", "interval"]) ??
        ""
    ).toLowerCase();
    const kind: NormalisedWebhookEvent["kind"] =
      rawType.includes("cancel")
        ? "subscription_canceled"
        : rawType.includes("fail") || rawType.includes("past_due")
          ? "payment_failed"
          : rawType.includes("active") ||
              rawType.includes("paid") ||
              rawType.includes("renew") ||
              rawType.includes("created") ||
              rawType.includes("succeed")
            ? "subscription_active"
            : "unknown";
    return {
      eventId: (pick(body, ["id", "event_id"]) as string | null) ?? null,
      userId,
      gatewayCustomerId,
      gatewaySubscriptionId,
      kind,
      planInterval:
        intervalRaw === "monthly" || intervalRaw === "yearly"
          ? intervalRaw
          : null,
      currentPeriodEnd:
        (pick(body, ["current_period_end"]) as string | null) ?? null,
    };
  },
};
