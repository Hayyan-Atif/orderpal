"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import type { Session } from "@supabase/supabase-js";
import { getSupabase } from "@/lib/supabase-client";

/** Redirects to /login when there is no session. Returns the session once known. */
export function useSession(): { session: Session | null; loading: boolean } {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const supabase = getSupabase();
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
      if (!data.session) router.replace("/login");
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      if (!s) router.replace("/login");
    });
    return () => sub.subscription.unsubscribe();
  }, [router]);

  return { session, loading };
}

/** Save the phone's timezone to the profile so daily limits reset at local midnight. */
export async function syncTimezone() {
  try {
    const supabase = getSupabase();
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { data: profile } = await supabase
      .from("profiles")
      .select("timezone")
      .eq("id", user.id)
      .single();
    if (profile && !profile.timezone) {
      await supabase.from("profiles").update({ timezone: tz }).eq("id", user.id);
    }
  } catch {
    /* non-critical */
  }
}
