import type { CustomerSummary, Order } from "@/lib/types";

function digitsOnly(phone: string | null): string {
  return (phone ?? "").replace(/\D/g, "");
}

/** Grouping key: normalised name + phone digits. Two spellings of the same
 *  name with the same phone are one customer; a customer with no phone is
 *  grouped by name alone. Nothing here invents a customer. */
export function customerKey(o: Order): string {
  const name = o.customer_name.trim().toLowerCase();
  const phone = digitsOnly(o.customer_phone);
  return phone ? `${name}|${phone}` : name;
}

export function deriveCustomers(orders: Order[]): CustomerSummary[] {
  const map = new Map<string, CustomerSummary>();
  for (const o of orders) {
    const key = customerKey(o);
    let c = map.get(key);
    if (!c) {
      c = {
        key,
        name: o.customer_name.trim(),
        phone: o.customer_phone,
        orderCount: 0,
        unpaidCount: 0,
        totalsByCurrency: {},
        paidByCurrency: {},
        owedByCurrency: {},
        firstOrderAt: o.created_at,
        lastOrderAt: o.created_at,
        orders: [],
      };
      map.set(key, c);
    }
    c.orderCount += 1;
    c.orders.push(o);
    const amt = Number(o.total) || 0;
    c.totalsByCurrency[o.currency] = (c.totalsByCurrency[o.currency] ?? 0) + amt;
    if (o.is_paid) {
      c.paidByCurrency[o.currency] = (c.paidByCurrency[o.currency] ?? 0) + amt;
    } else {
      c.unpaidCount += 1;
      c.owedByCurrency[o.currency] = (c.owedByCurrency[o.currency] ?? 0) + amt;
    }
    if (o.created_at < c.firstOrderAt) c.firstOrderAt = o.created_at;
    if (o.created_at > c.lastOrderAt) c.lastOrderAt = o.created_at;
  }
  const list = Array.from(map.values());
  for (const c of list) {
    c.orders.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
  }
  // Most owed first, then most orders — the seller's collection priority.
  const owedTotal = (c: CustomerSummary) =>
    Object.values(c.owedByCurrency).reduce((s, v) => s + v, 0);
  list.sort((a, b) => owedTotal(b) - owedTotal(a) || b.orderCount - a.orderCount);
  return list;
}

export function sumByCurrency(
  orders: Order[],
  pick: (o: Order) => boolean
): Record<string, number> {
  const t: Record<string, number> = {};
  for (const o of orders) {
    if (!pick(o)) continue;
    t[o.currency] = (t[o.currency] ?? 0) + (Number(o.total) || 0);
  }
  return t;
}
