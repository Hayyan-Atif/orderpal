import type { Order, WeeklySummary } from "@/lib/types";
import { deriveCustomers } from "@/lib/customers";

/**
 * Weekly summary = the last 7 days (today + previous 6 days), computed only
 * from the user's own orders. "New customer" = first-ever order in the window.
 * Top customers are ranked by total order value in the window, one row per
 * customer per currency (currencies are never converted or mixed).
 */
export function weeklySummary(orders: Order[], now = new Date()): WeeklySummary {
  const end = now;
  const start = new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000);
  start.setHours(0, 0, 0, 0);
  const inWindow = orders.filter((o) => {
    const t = new Date(o.created_at).getTime();
    return t >= start.getTime() && t <= end.getTime();
  });

  const totalsByCurrency: Record<string, number> = {};
  const paidByCurrency: Record<string, number> = {};
  const owedByCurrency: Record<string, number> = {};
  for (const o of inWindow) {
    const amt = Number(o.total) || 0;
    totalsByCurrency[o.currency] = (totalsByCurrency[o.currency] ?? 0) + amt;
    if (o.is_paid) paidByCurrency[o.currency] = (paidByCurrency[o.currency] ?? 0) + amt;
    else owedByCurrency[o.currency] = (owedByCurrency[o.currency] ?? 0) + amt;
  }

  const allCustomers = deriveCustomers(orders);
  const newCustomers = allCustomers
    .filter((c) => {
      const first = new Date(c.firstOrderAt).getTime();
      return first >= start.getTime() && first <= end.getTime();
    })
    .map((c) => c.name);

  const weekCustomers = deriveCustomers(inWindow);
  const topCustomers = weekCustomers
    .flatMap((c) =>
      Object.entries(c.totalsByCurrency).map(([currency, total]) => ({
        name: c.name,
        total,
        currency,
      }))
    )
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  return {
    start: start.toISOString().slice(0, 10),
    end: end.toISOString().slice(0, 10),
    orderCount: inWindow.length,
    totalsByCurrency,
    paidByCurrency,
    owedByCurrency,
    newCustomers,
    topCustomers,
  };
}
