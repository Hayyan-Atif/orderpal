import { createClient } from "@supabase/supabase-js";

/**
 * Service-role client — SERVER ONLY, for webhooks.
 * Webhooks arrive without a user session, so they cannot use the
 * user-token client (RLS would block updating another user's row).
 * Returns null when SUPABASE_SERVICE_ROLE_KEY is not set; webhook routes
 * then refuse the event rather than applying it unsafely. This key must
 * NEVER be exposed to the browser or committed to the repo.
 */
export function serviceClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false } });
}
