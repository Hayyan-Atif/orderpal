import type { Order } from "@/lib/types";
import { formatMoney } from "@/lib/currencies";

/** Unpaid orders, most overdue first: passed due date first, then oldest. */
export function overdueOrders(orders: Order[], today = new Date()): Order[] {
  const todayStr = today.toISOString().slice(0, 10);
  return orders
    .filter((o) => !o.is_paid)
    .sort((a, b) => {
      const aOver = a.due_date ? a.due_date < todayStr : false;
      const bOver = b.due_date ? b.due_date < todayStr : false;
      if (aOver !== bOver) return aOver ? -1 : 1;
      return (a.due_date ?? "9999") < (b.due_date ?? "9999")
        ? -1
        : a.created_at < b.created_at
          ? -1
          : 1;
    });
}

export function isOverdue(o: Order, today = new Date()): boolean {
  return !!o.due_date && o.due_date < today.toISOString().slice(0, 10);
}

/** Fallback draft used when AI is unavailable. Never sent automatically. */
export function fallbackDraft(o: Order): string {
  const items = o.items.map((i) => `${i.qty}× ${i.name}`).join(", ");
  const due = o.due_date ? `, due ${o.due_date}` : "";
  return (
    `Hi ${o.customer_name}, just a friendly reminder about your OrderPal order` +
    (items ? ` (${items})` : "") +
    ` — ${formatMoney(o.total, o.currency)} is still unpaid${due}. ` +
    `Could you please send the payment when you get a chance? Thank you!`
  );
}

/**
 * wa.me link for a draft. Returns null when there is no phone number —
 * the seller then copies the draft instead. This link only OPENS WhatsApp
 * with the text pre-filled; it never sends anything on its own.
 */
export function waLink(phone: string | null, draft: string): string | null {
  const digits = (phone ?? "").replace(/\D/g, "");
  if (!digits) return null;
  return `https://wa.me/${digits}?text=${encodeURIComponent(draft)}`;
}
