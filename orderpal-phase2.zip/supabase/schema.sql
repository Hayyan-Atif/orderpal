-- OrderPal database schema. Run this in your Supabase project:
-- Dashboard > SQL Editor > New query > paste > Run.

-- One profile row per user. Created automatically on sign-up (see trigger below).
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  default_currency text not null default 'USD',
  timezone text not null default 'UTC',
  -- plan: 'free' | 'active' | 'past_due' | 'canceled'
  -- (subscription fields are used by the phase-2 payment integration)
  plan text not null default 'free',
  plan_interval text, -- 'monthly' | 'yearly'
  created_at timestamptz not null default now()
);

create table orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  customer_name text not null,
  customer_phone text,
  -- items: [{"name": "Chocolate cake", "qty": 2, "price": 15}]
  items jsonb not null default '[]'::jsonb,
  total numeric not null default 0,
  currency text not null default 'USD',
  due_date date,
  notes text,
  is_paid boolean not null default false,
  is_delivered boolean not null default false,
  -- the original WhatsApp message, kept so reminders can match its language
  source_message text,
  source_language text,
  created_at timestamptz not null default now()
);

create index orders_user_created_idx on orders (user_id, created_at desc);

-- Row-level security: users can only ever touch their own rows.
alter table profiles enable row level security;
alter table orders enable row level security;

create policy "Users manage their own profile"
  on profiles for all
  using (auth.uid() = id)
  with check (auth.uid() = id);

create policy "Users manage their own orders"
  on orders for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Auto-create a profile the moment someone signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id)
  values (new.id)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
