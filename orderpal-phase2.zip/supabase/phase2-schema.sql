-- OrderPal Phase 2 migration. Run AFTER supabase/schema.sql, in the same way:
-- Dashboard > SQL Editor > New query > paste > Run.
-- Do NOT re-run schema.sql (it is the v0.1 baseline and stays untouched).

-- One subscription row per user (the latest gateway subscription).
create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references profiles(id) on delete cascade,
  gateway text not null default 'safepay', -- 'safepay' | 'paypro'
  gateway_customer_id text,
  gateway_subscription_id text,
  plan_interval text, -- 'monthly' | 'yearly'
  -- status: 'active' | 'past_due' | 'canceled'
  status text not null default 'canceled',
  failed_renewal_attempts integer not null default 0,
  first_failed_at timestamptz,
  last_failed_at timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- One row per AI reminder draft, so the 50/day limit is counted server-side.
create table if not exists reminder_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  order_id uuid references orders(id) on delete cascade,
  draft text not null,
  created_at timestamptz not null default now()
);
create index if not exists reminder_logs_user_created_idx
  on reminder_logs (user_id, created_at desc);

-- Webhook delivery dedupe: one row per gateway event id.
create table if not exists subscription_events (
  id uuid primary key default gen_random_uuid(),
  gateway text not null,
  event_id text not null,
  event_type text,
  payload jsonb,
  created_at timestamptz not null default now(),
  unique (gateway, event_id)
);

-- Row-level security: users only ever see their own rows.
-- (Webhook routes use the service-role key, which bypasses RLS.)
alter table subscriptions enable row level security;
alter table reminder_logs enable row level security;
alter table subscription_events enable row level security;

drop policy if exists "Users manage their own subscription" on subscriptions;
create policy "Users manage their own subscription"
  on subscriptions for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users manage their own reminder logs" on reminder_logs;
create policy "Users manage their own reminder logs"
  on reminder_logs for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- No user policy on subscription_events: only the service-role webhook
-- handler reads/writes it, so app users cannot see raw gateway payloads.
